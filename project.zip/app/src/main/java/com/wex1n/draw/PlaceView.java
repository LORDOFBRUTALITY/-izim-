package com.wex1n.draw;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/** Resmi ekranda sürükleyip yakınlaştırarak yerleştirme görünümü (tüm koordinatlar ekran koordinatı). */
public class PlaceView extends View {
    final Bitmap bmp;
    final RectF area = new RectF();
    final Paint pImg = new Paint(Paint.FILTER_BITMAP_FLAG);
    final Paint pArea = new Paint();
    final ScaleGestureDetector sgd;
    final int[] loc = new int[2];
    float tx, ty, sc = 1, lx, ly;

    public PlaceView(Context c, Bitmap b, RectF a) {
        super(c);
        bmp = b;
        area.set(a);
        pImg.setAlpha(165);
        pArea.setStyle(Paint.Style.STROKE);
        pArea.setColor(0xFF00E5FF);
        pArea.setStrokeWidth(4);
        sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector d) {
                float f = d.getScaleFactor();
                float fx = d.getFocusX() + loc[0], fy = d.getFocusY() + loc[1];
                tx = fx - (fx - tx) * f;
                ty = fy - (fy - ty) * f;
                sc *= f;
                invalidate();
                return true;
            }
        });
        fit();
    }

    public void fit() {
        float s = Math.min(area.width() / bmp.getWidth(), area.height() / bmp.getHeight());
        place(s);
    }

    public void fill() {
        float s = Math.max(area.width() / bmp.getWidth(), area.height() / bmp.getHeight());
        place(s);
    }

    void place(float s) {
        sc = s;
        tx = area.centerX() - bmp.getWidth() * s / 2;
        ty = area.centerY() - bmp.getHeight() * s / 2;
        invalidate();
    }

    public RectF imageRect() {
        return new RectF(tx, ty, tx + bmp.getWidth() * sc, ty + bmp.getHeight() * sc);
    }

    public RectF areaRect() {
        return new RectF(area);
    }

    @Override
    protected void onDraw(Canvas cv) {
        getLocationOnScreen(loc);
        cv.save();
        cv.translate(-loc[0], -loc[1]);
        cv.save();
        cv.translate(tx, ty);
        cv.scale(sc, sc);
        cv.drawBitmap(bmp, 0, 0, pImg);
        cv.restore();
        cv.drawRect(area, pArea);
        cv.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        getLocationOnScreen(loc);
        sgd.onTouchEvent(e);
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) {
            lx = e.getRawX();
            ly = e.getRawY();
        } else if (act == MotionEvent.ACTION_MOVE && e.getPointerCount() == 1 && !sgd.isInProgress()) {
            tx += e.getRawX() - lx;
            ty += e.getRawY() - ly;
            lx = e.getRawX();
            ly = e.getRawY();
            invalidate();
        } else if (act == MotionEvent.ACTION_POINTER_UP || act == MotionEvent.ACTION_UP) {
            int keep = e.getActionIndex() == 0 ? 1 : 0;
            if (e.getPointerCount() > 1) {
                lx = e.getX(keep) + loc[0];
                ly = e.getY(keep) + loc[1];
            }
        }
        return true;
    }
}
