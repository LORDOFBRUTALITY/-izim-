package com.wex1n.draw;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.os.Bundle;

public class PickActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, 1);
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rs == RESULT_OK && d != null && d.getData() != null) {
            try {
                Bitmap bm = ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContentResolver(), d.getData()),
                    (dec, info, src) -> {
                        int m = Math.max(info.getSize().getWidth(), info.getSize().getHeight());
                        dec.setTargetSampleSize(Math.max(1, m / 2000));
                        dec.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                    });
                DrawService.onPicked(this, bm);
            } catch (Exception e) {
                DrawService.toast("Resim açılamadı: " + e.getMessage());
            }
        }
        finish();
    }
}
