package com.wex1n.draw;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class DrawService extends AccessibilityService {
    static final String IG = "com.instagram.android";
    static final boolean EXACT = true;
    static DrawService instance;
    static Bitmap pending;

    static class Ent {
        int x, y, rgb, page;

        Ent(int x, int y, int rgb, int page) {
            this.x = x;
            this.y = y;
            this.rgb = rgb;
            this.page = page;
        }
    }

    final Handler main = new Handler(Looper.getMainLooper());
    WindowManager wm;
    LinearLayout panel;
    TextView logView;
    Button bGo;
    int sw, sh;
    volatile boolean stop = false;
    volatile boolean running = false;
    final List<String> logs = new ArrayList<>();
    final StringBuilder allLog = new StringBuilder();
    FrameLayout placeRoot;
    PlaceView placeView;
    int quality = 1;
    boolean enhanceOn = true;
    boolean lineMode = true;

    List<Ent> ents = new ArrayList<>();
    int curPage = 0;
    int curEnt = -1;
    Detect.Slider slider;
    float knobY = -1;
    List<float[]> M = new ArrayList<>();
    float curF = -1;

    // ---------------- Yaşam döngüsü ----------------
    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Rect b = wm.getMaximumWindowMetrics().getBounds();
        sw = b.width();
        sh = b.height();
        buildPanel();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (panel == null || running || placeRoot != null) return;
        CharSequence cs = e.getPackageName();
        if (cs == null) return;
        String pkg = cs.toString();
        if (pkg.equals(getPackageName())) return;
        if (pkg.equals(IG)) {
            panel.setVisibility(View.VISIBLE);
        } else if (!pkg.contains("systemui") && !pkg.contains("inputmethod") && !pkg.contains("keyboard")) {
            panel.setVisibility(View.GONE);
        }
    }

    @Override
    public void onInterrupt() {
        stop = true;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
    }

    static void toast(String m) {
        final DrawService s = instance;
        if (s != null) s.main.post(() -> Toast.makeText(s, m, Toast.LENGTH_LONG).show());
    }

    static void onPicked(Context c, Bitmap bm) {
        try {
            FileOutputStream fo = new FileOutputStream(new File(c.getCacheDir(), "last.png"));
            bm.compress(Bitmap.CompressFormat.PNG, 100, fo);
            fo.close();
        } catch (Exception e) {
            // önbelleğe yazılamadı, yine de devam
        }
        pending = bm;
        final DrawService s = instance;
        if (s != null) s.main.post(s::showPlacement);
    }

    // ---------------- Panel ----------------
    Button mk(String t, View.OnClickListener c) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(22, 8, 22, 8);
        b.setOnClickListener(c);
        return b;
    }

    void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xDD000000);
        panel.setPadding(8, 2, 8, 2);
        LinearLayout row = new LinearLayout(this);
        row.addView(mk("Resim", v -> pickImage()));
        row.addView(mk("Son resim", v -> useLast()));
        row.addView(mk("Dur", v -> stop = true));
        row.addView(mk("Rapor", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("log", allLog.toString()));
            Toast.makeText(this, "Rapor kopyalandı", Toast.LENGTH_SHORT).show();
        }));
        bGo = mk("Devam", v -> { });
        bGo.setVisibility(View.GONE);
        row.addView(bGo);
        logView = new TextView(this);
        logView.setTextColor(0xFFFFFFFF);
        logView.setTextSize(13);
        logView.setMaxLines(1);
        logView.setEllipsize(TextUtils.TruncateAt.END);
        panel.addView(row);
        panel.addView(logView);
        panel.setVisibility(View.GONE);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            (int) (sw * 0.75), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(panel, lp);
        log("Çizim ekranını aç, sonra 'Resim'e bas.");
    }

    void log(String m) {
        synchronized (logs) {
            logs.add(m);
            while (logs.size() > 4) logs.remove(0);
            allLog.append(m).append('\n');
            if (allLog.length() > 20000) allLog.delete(0, 5000);
        }
        main.post(() -> logView.setText(m));
    }

    void pickImage() {
        if (running) return;
        try {
            Intent i = new Intent(this, PickActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            log("Galeri açılamadı: " + e.getMessage());
        }
    }

    void useLast() {
        if (running) return;
        File f = new File(getCacheDir(), "last.png");
        if (!f.exists()) {
            log("Kayıtlı resim yok. 'Resim'e bas.");
            return;
        }
        pending = BitmapFactory.decodeFile(f.getAbsolutePath());
        showPlacement();
    }

    // ---------------- Yerleştirme ----------------
    void showPlacement() {
        if (pending == null || running || placeRoot != null) return;
        log("Ekran taranıyor...");
        new Thread(() -> {
            Bitmap b = shot();
            if (b == null) {
                log("Ekran görüntüsü alınamadı.");
                return;
            }
            int w = b.getWidth(), h = b.getHeight();
            int[] px = pixels(b);
            b.recycle();
            final Detect.Pal pal = Detect.palette(px, w, h);
            if (pal == null) {
                log("Çizim ekranı bulunamadı. Instagram'da çizim ekranını açık tut.");
                return;
            }
            final RectF area = new RectF(pal.left, h * 0.10f, pal.right, pal.y - 55);
            main.post(() -> buildPlaceOverlay(area));
        }).start();
    }

    void buildPlaceOverlay(RectF area) {
        placeRoot = new FrameLayout(this);
        placeView = new PlaceView(this, pending, area);
        placeRoot.addView(placeView);
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(0xDD000000);
        bar.setPadding(8, 8, 8, 8);
        LinearLayout r1 = new LinearLayout(this);
        LinearLayout r2 = new LinearLayout(this);
        r1.addView(mk("Sığdır", v -> placeView.fit()));
        r1.addView(mk("Doldur", v -> placeView.fill()));
        final Button bm = mk(mName(), v -> { });
        bm.setOnClickListener(v -> {
            lineMode = !lineMode;
            bm.setText(mName());
        });
        r1.addView(bm);
        final Button bq = mk(qName(), v -> { });
        bq.setOnClickListener(v -> {
            quality = (quality + 1) % 3;
            bq.setText(qName());
        });
        r2.addView(bq);
        final Button be = mk(eName(), v -> { });
        be.setOnClickListener(v -> {
            enhanceOn = !enhanceOn;
            be.setText(eName());
        });
        r2.addView(be);
        r2.addView(mk("BAŞLAT", v -> startFromPlacement()));
        r2.addView(mk("İptal", v -> removePlacement()));
        bar.addView(r1);
        bar.addView(r2);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        fl.bottomMargin = 160;
        placeRoot.addView(bar, fl);
        TextView hint = new TextView(this);
        hint.setText("Sürükle: taşı · İki parmak: büyüt/küçült · Turkuaz çerçeve çizilecek alan");
        hint.setTextColor(0xFFFFFFFF);
        hint.setBackgroundColor(0xAA000000);
        hint.setTextSize(14);
        hint.setPadding(12, 8, 12, 8);
        placeRoot.addView(hint, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        wm.addView(placeRoot, lp);
    }

    String mName() {
        return "Mod: " + (lineMode ? "Çizgi film" : "Fotoğraf");
    }

    String eName() {
        return "İyileştir: " + (enhanceOn ? "Açık" : "Kapalı");
    }

    String qName() {
        return "Kalite: " + (quality == 0 ? "Hızlı" : quality == 1 ? "Normal" : "Detaylı");
    }

    void removePlacement() {
        if (placeRoot != null) {
            try {
                wm.removeView(placeRoot);
            } catch (Exception e) {
                // yoksay
            }
            placeRoot = null;
            placeView = null;
        }
    }

    void startFromPlacement() {
        final RectF img = placeView.imageRect();
        final RectF area = placeView.areaRect();
        final Bitmap bmp = pending;
        final int q = quality;
        final boolean enh = enhanceOn;
        removePlacement();
        stop = false;
        running = true;
        new Thread(() -> {
            try {
                runImage(bmp, img, area, q, enh);
            } catch (Throwable e) {
                log("HATA: " + e);
            } finally {
                running = false;
            }
        }).start();
    }

    // ---------------- Dokunuş yardımcıları ----------------
    float cx(float x) {
        return Math.max(1, Math.min(sw - 2, x));
    }

    float cy(float y) {
        return Math.max(1, Math.min(sh - 2, y));
    }

    void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            // yoksay
        }
    }

    boolean dispatch(GestureDescription g, long waitMs) {
        final CountDownLatch l = new CountDownLatch(1);
        final boolean[] ok = {false};
        main.post(() -> {
            boolean r = dispatchGesture(g, new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gd) {
                    ok[0] = true;
                    l.countDown();
                }

                @Override
                public void onCancelled(GestureDescription gd) {
                    l.countDown();
                }
            }, null);
            if (!r) l.countDown();
        });
        try {
            l.await(waitMs + 5000, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            // yoksay
        }
        sleep(25);
        return ok[0];
    }

    void tap(float x, float y) {
        Path p = new Path();
        p.moveTo(cx(x), cy(y));
        dispatch(new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p, 0, 60)).build(), 60);
    }

    void drag(float x1, float y1, float x2, float y2, long dur) {
        Path p = new Path();
        p.moveTo(cx(x1), cy(y1));
        float ex = cx(x2), ey = cy(y2);
        if (Math.abs(ex - cx(x1)) < 1 && Math.abs(ey - cy(y1)) < 1) ey += 1;
        p.lineTo(ex, ey);
        dispatch(new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p, 0, dur)).build(), dur);
    }

    /** Aynı renk ve boyuttaki çizgileri tek hareket içinde, sırayla çizer. */
    void strokeBatch(List<float[]> segs) {
        if (segs.isEmpty()) return;
        GestureDescription.Builder gb = new GestureDescription.Builder();
        long t = 0;
        for (float[] s : segs) {
            float x0 = cx(s[0]), y0 = cy(s[1]), x1 = cx(s[2]), y1 = cy(s[3]);
            if (Math.abs(x1 - x0) < 1 && Math.abs(y1 - y0) < 1) x1 = x0 + 1;
            Path p = new Path();
            p.moveTo(x0, y0);
            p.lineTo(x1, y1);
            long dur = (long) Math.max(35, Math.hypot(x1 - x0, y1 - y0) / 1.6);
            gb.addStroke(new GestureDescription.StrokeDescription(p, t, dur));
            t += dur + 12;
        }
        dispatch(gb.build(), t);
    }

    // ---------------- Ekran görüntüsü ----------------
    Bitmap shot() {
        for (int i = 0; i < 3; i++) {
            sleep(450);
            Bitmap r = shot1();
            if (r != null) return r;
        }
        return null;
    }

    Bitmap shot1() {
        final int[] vis = {View.VISIBLE};
        main.post(() -> {
            if (panel != null) {
                vis[0] = panel.getVisibility();
                panel.setVisibility(View.INVISIBLE);
            }
        });
        sleep(150);
        Bitmap res = shot2();
        main.post(() -> {
            if (panel != null) panel.setVisibility(vis[0]);
        });
        return res;
    }

    Bitmap shot2() {
        final Bitmap[] out = new Bitmap[1];
        final CountDownLatch l = new CountDownLatch(1);
        main.post(() -> takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override
            public void onSuccess(ScreenshotResult r) {
                try {
                    Bitmap hw = Bitmap.wrapHardwareBuffer(r.getHardwareBuffer(), r.getColorSpace());
                    out[0] = hw.copy(Bitmap.Config.ARGB_8888, false);
                    r.getHardwareBuffer().close();
                } catch (Throwable t) {
                    out[0] = null;
                }
                l.countDown();
            }

            @Override
            public void onFailure(int code) {
                l.countDown();
            }
        }));
        try {
            l.await(4, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            // yoksay
        }
        return out[0];
    }

    int[] pixels(Bitmap b) {
        int[] px = new int[b.getWidth() * b.getHeight()];
        b.getPixels(px, 0, b.getWidth(), 0, 0, b.getWidth(), b.getHeight());
        return px;
    }

    // ---------------- Bekleme ----------------
    void waitUser(String msg) {
        final CountDownLatch go = new CountDownLatch(1);
        log(msg);
        main.post(() -> {
            bGo.setVisibility(View.VISIBLE);
            bGo.setOnClickListener(v -> {
                bGo.setVisibility(View.GONE);
                go.countDown();
            });
        });
        while (!stop) {
            try {
                if (go.await(500, TimeUnit.MILLISECONDS)) break;
            } catch (InterruptedException e) {
                // yoksay
            }
        }
        main.post(() -> bGo.setVisibility(View.GONE));
    }

    // ---------------- Araç seçimi ----------------
    boolean ensurePen() {
        for (int a = 0; a < 3; a++) {
            Bitmap b = shot();
            if (b == null) return false;
            int w = b.getWidth(), h = b.getHeight();
            int[] px = pixels(b);
            b.recycle();
            Detect.Pal p = Detect.palette(px, w, h);
            if (p == null) return false;
            Detect.Tools t = Detect.tools(px, w, h, p.left, p.right);
            if (t == null) return false;
            if (t.selected == 0) return true;
            tap(t.x[0], t.y);
            sleep(500);
        }
        return false;
    }

    // ---------------- Palet ----------------
    int cd(int a, int b) {
        return Math.abs(((a >> 16) & 255) - ((b >> 16) & 255)) + Math.abs(((a >> 8) & 255) - ((b >> 8) & 255))
            + Math.abs((a & 255) - (b & 255));
    }

    Detect.Pal scanPalette() {
        Bitmap b = shot();
        if (b == null) return null;
        int w = b.getWidth(), h = b.getHeight();
        int[] px = pixels(b);
        b.recycle();
        Detect.Pal p = Detect.palette(px, w, h);
        if (p != null) {
            Detect.Slider s = Detect.slider(px, w, h, p.left - 20, 260);
            if (s != null && slider == null) slider = s;
        }
        return p;
    }

    /** Paleti ve (varsa) ikinci sayfasını ezberler. */
    boolean learnPalette() {
        ents.clear();
        curPage = 0;
        curEnt = -1;
        Detect.Pal p = scanPalette();
        if (p == null) return false;
        for (Detect.Sw s : p.sw) ents.add(new Ent(s.x, s.y, s.rgb, 0));
        int n1 = ents.size();
        drag(p.right - 70, p.y, p.left + 220, p.y, 320);
        sleep(700);
        Detect.Pal p2 = scanPalette();
        int added = 0;
        if (p2 != null) {
            for (Detect.Sw s : p2.sw) {
                boolean dup = false;
                for (Ent e : ents) {
                    if (cd(e.rgb, s.rgb) < 30) {
                        dup = true;
                        break;
                    }
                }
                if (!dup) {
                    ents.add(new Ent(s.x, s.y, s.rgb, 1));
                    added++;
                }
            }
        }
        log("Palet: " + n1 + " + " + added + " renk");
        drag(p.left + 220, p.y, p.right - 70, p.y, 320);
        sleep(700);
        curPage = 0;
        return true;
    }

    void selectEnt(int idx) {
        if (idx == curEnt) return;
        Ent e = ents.get(idx);
        if (e.page != curPage) {
            Detect.Pal p = scanPalette();
            if (p == null) return;
            if (e.page == 1) drag(p.right - 70, p.y, p.left + 220, p.y, 320);
            else drag(p.left + 220, p.y, p.right - 70, p.y, 320);
            sleep(700);
            curPage = e.page;
            curEnt = -1;
            Detect.Pal q = scanPalette();
            if (q != null) {
                Detect.Sw best = null;
                int bd = 1 << 30;
                for (Detect.Sw s : q.sw) {
                    int d = cd(s.rgb, e.rgb);
                    if (d < bd) {
                        bd = d;
                        best = s;
                    }
                }
                if (best != null) {
                    tap(best.x, best.y);
                    curEnt = idx;
                    return;
                }
            }
        }
        tap(e.x, e.y);
        curEnt = idx;
    }

    int nearestEnt(int rgb) {
        int best = 0, bd = 1 << 30;
        for (int i = 0; i < ents.size(); i++) {
            int d = cd(ents.get(i).rgb, rgb);
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
        return best;
    }

    // ---------------- Fırça boyutu ----------------
    float fFromY(float y) {
        return (slider.yBottom - y) / (slider.yBottom - slider.yTop);
    }

    float readKnobY() {
        Bitmap b = shot();
        if (b == null) return -1;
        int w = b.getWidth(), h = b.getHeight();
        int[] px = pixels(b);
        b.recycle();
        int[] k = Detect.knobAt(px, w, h, slider.x, slider.yTop - 25, slider.yBottom + 25);
        return k == null ? -1 : k[1];
    }

    /** Fırça boyutunu ayarlar; topuğun gerçekten gittiğini ekran görüntüsünden doğrular. */
    void setF(float f) {
        if (slider == null || Math.abs(f - curF) < 0.02f) return;
        float x = slider.x;
        float y = slider.yBottom + (slider.yTop - slider.yBottom) * f;
        for (int attempt = 0; attempt < 3; attempt++) {
            float from = knobY >= 0 ? knobY : slider.knobY;
            if (attempt == 0) drag(x, from, x, y, 500);
            else if (attempt == 1) tap(x, y);
            else drag(x, y + 30, x, y, 500);
            float ky = readKnobY();
            if (ky < 0) {
                knobY = y;
                curF = f;
                return;
            }
            knobY = ky;
            if (Math.abs(ky - y) < 16) {
                curF = fFromY(ky);
                return;
            }
        }
        curF = fFromY(knobY);
        log("Fırça boyu ayarlanamadı (hedef " + Math.round(f * 100) + "%)");
    }

    float w2f(float w) {
        if (M.size() < 2) return 0.5f;
        List<float[]> a = new ArrayList<>(M);
        java.util.Collections.sort(a, (p, q) -> Float.compare(p[1], q[1]));
        if (w <= a.get(0)[1]) return a.get(0)[0];
        for (int i = 1; i < a.size(); i++) {
            if (w <= a.get(i)[1]) {
                float f0 = a.get(i - 1)[0], w0 = a.get(i - 1)[1], f1 = a.get(i)[0], w1 = a.get(i)[1];
                return w1 == w0 ? f1 : f0 + (f1 - f0) * (w - w0) / (w1 - w0);
            }
        }
        return a.get(a.size() - 1)[0];
    }

    float measure(Bitmap b, int x, int y) {
        if (x < 0 || y < 0 || x >= b.getWidth() || y >= b.getHeight()) return -1;
        int ref = b.getPixel(x, y);
        int n = 1;
        for (int yy = y - 1; yy >= 0 && cd(b.getPixel(x, yy), ref) < 70; yy--) n++;
        for (int yy = y + 1; yy < b.getHeight() && cd(b.getPixel(x, yy), ref) < 70; yy++) n++;
        return n;
    }

    // ---------------- Çizim ----------------
    void runImage(Bitmap bmp, RectF img, RectF area, int q, boolean enh) throws Exception {
        curF = -1;
        knobY = -1;
        curEnt = -1;
        M = new ArrayList<>();
        slider = null;
        log("Kalem aracı seçiliyor...");
        if (ensurePen()) {
            log("Kalem seçili.");
        } else {
            waitUser("Kalemi (1. ikon) sen seç, sonra Devam.");
            if (stop) return;
        }
        log("Arayüz taranıyor...");
        if (!learnPalette() || ents.size() < 5) {
            log("Palet bulunamadı. Durdum.");
            return;
        }
        log(slider != null ? "Çubuk x=" + slider.x + " y=" + slider.yTop + ".." + slider.yBottom + " topuz=" + slider.knobY : "Fırça çubuğu YOK, tek boy.");

        float rl = Math.max(img.left, area.left), rt = Math.max(img.top, area.top);
        float rr = Math.min(img.right, area.right), rb = Math.min(img.bottom, area.bottom);
        if (rr - rl < 40 || rb - rt < 40) {
            log("Resim çizim alanının dışında.");
            return;
        }

        if (EXACT) {
            runExact(bmp, img, rl, rt, rr, rb, q, enh);
            return;
        }

        log("Fırça ölçülüyor...");
        selectEnt(nearestEnt(0x262626));
        float[] fs = slider != null ? new float[]{0, 0.25f, 0.5f, 0.75f, 1} : new float[]{0.5f};
        float pxm = (rl + rr) / 2;
        float half = Math.min(120, (rr - rl) * 0.3f);
        for (int i = 0; i < fs.length && !stop; i++) {
            setF(fs[i]);
            float y = rt + (rb - rt) * (i + 0.7f) / (fs.length + 0.4f);
            List<float[]> one = new ArrayList<>();
            one.add(new float[]{pxm - half, y, pxm + half, y});
            strokeBatch(one);
            Bitmap b = shot();
            if (b != null) {
                float w = measure(b, (int) pxm, (int) y);
                b.recycle();
                if (w > 2) M.add(new float[]{slider != null ? curF : fs[i], w});
            }
        }
        float wmin, wmax;
        if (M.size() >= 2) {
            wmin = 1e9f;
            wmax = 0;
            StringBuilder sb = new StringBuilder("Boy: ");
            for (float[] m : M) {
                wmin = Math.min(wmin, m[1]);
                wmax = Math.max(wmax, m[1]);
                sb.append(Math.round(m[0] * 100) / 100f).append('=').append((int) m[1]).append(' ');
            }
            log(sb.toString());
        } else if (M.size() == 1) {
            wmin = wmax = M.get(0)[1];
            log("Tek fırça boyu: " + (int) wmin);
        } else {
            wmin = Math.max(8, sw * 0.012f);
            wmax = sw * 0.12f;
            log("Ölçüm olmadı, varsayılan boyutlar.");
        }

        if (lineMode) {
            runLine(bmp, img, rl, rt, rr, rb, q, wmin, wmax);
            return;
        }

        int[] passes = {3, 4, 5};
        int[] caps = {1800, 3800, 7500};
        int np = passes[q];
        float dTop = Math.min(wmax, 0.07f * Math.max(rr - rl, rb - rt));
        float dBot = Math.max(wmin * 1.15f, 6f);
        if (dTop <= dBot * 1.5f || M.size() < 2) np = 1;
        if (np == 1) dTop = Math.max(dBot, Math.min(dTop, wmax));
        float[] sizes = new float[np];
        for (int i = 0; i < np; i++) {
            sizes[i] = np == 1 ? dTop : (float) (dTop * Math.pow(dBot / dTop, i / (double) (np - 1)));
        }

        log("Plan hazırlanıyor...");
        float sc = Math.max(2f, Math.round(Math.min(sizes[np - 1], 12) / 3f));
        int cw = (int) ((rr - rl) / sc), ch = (int) ((rb - rt) / sc);
        while ((long) cw * ch > 650000) {
            sc += 1;
            cw = (int) ((rr - rl) / sc);
            ch = (int) ((rb - rt) / sc);
        }
        float sx = bmp.getWidth() / (img.right - img.left), sy = bmp.getHeight() / (img.bottom - img.top);
        int bx = Math.max(0, Math.round((rl - img.left) * sx));
        int by = Math.max(0, Math.round((rt - img.top) * sy));
        int bw = Math.max(1, Math.min(bmp.getWidth() - bx, Math.round((rr - rl) * sx)));
        int bh = Math.max(1, Math.min(bmp.getHeight() - by, Math.round((rb - rt) * sy)));
        Bitmap crop = Bitmap.createBitmap(bmp, bx, by, bw, bh);
        Bitmap small = Bitmap.createScaledBitmap(crop, cw, ch, true);
        int[] px = pixels(small);
        if (enh) Planner.enhance(px, cw, ch);
        int[] pal = new int[ents.size()];
        for (int i = 0; i < pal.length; i++) pal[i] = ents.get(i).rgb;
        Planner.Plan plan = Planner.plan(px, cw, ch, sc, pal, sizes, -1, caps[q]);
        int total = plan.strokes.size();
        log("Plan: " + total + " darbe, " + np + " geçiş");

        int done = 0;
        int i = 0;
        while (i < total && !stop) {
            Planner.Stroke s0 = plan.strokes.get(i);
            int pass = s0.pass;
            int color = s0.color;
            setF(w2f(sizes[pass]));
            selectEnt(color);
            List<float[]> batch = new ArrayList<>();
            while (i < total && !stop) {
                Planner.Stroke s = plan.strokes.get(i);
                if (s.pass != pass || s.color != color) break;
                batch.add(new float[]{rl + s.x0, rt + s.y0, rl + s.x1, rt + s.y1});
                i++;
                if (batch.size() >= 10) {
                    strokeBatch(batch);
                    done += batch.size();
                    batch.clear();
                    log("Çiziliyor: " + done + "/" + total);
                }
            }
            if (!batch.isEmpty()) {
                strokeBatch(batch);
                done += batch.size();
            }
        }
        log(stop ? "Durduruldu." : "Bitti (" + done + " darbe). Göndermeyi sen yap.");
    }

    /** Birden çok çok-noktalı çizgiyi (polyline) sırayla tek harekette çizer. */
    void polyBatch(List<float[]> polys) {
        GestureDescription.Builder gb = new GestureDescription.Builder();
        long t = 0;
        int cnt = 0;
        for (float[] pts : polys) {
            Path p = new Path();
            float px = cx(pts[0]), py = cy(pts[1]);
            p.moveTo(px, py);
            float len = 0;
            if (pts.length == 2) {
                p.lineTo(px + 1, py);
                len = 1;
            }
            for (int i = 2; i < pts.length; i += 2) {
                float x = cx(pts[i]), y = cy(pts[i + 1]);
                p.lineTo(x, y);
                len += (float) Math.hypot(x - px, y - py);
                px = x;
                py = y;
            }
            long dur = (long) Math.max(35, Math.min(20000, len / 1.6));
            if (t + dur > 50000 || cnt >= 9) {
                dispatch(gb.build(), t);
                gb = new GestureDescription.Builder();
                t = 0;
                cnt = 0;
            }
            gb.addStroke(new GestureDescription.StrokeDescription(p, t, dur));
            cnt++;
            t += dur + 12;
        }
        if (cnt > 0) dispatch(gb.build(), t);
    }

    void runLine(Bitmap bmp, RectF img, float rl, float rt, float rr, float rb, int q, float wmin, float wmax) {
        float lo = Math.max(wmin, 5f);
        float hi = Math.max(wmax, lo * 1.5f);
        int nl = M.size() < 2 ? 1 : 7;
        float[] levels = new float[nl];
        for (int i = 0; i < nl; i++) {
            levels[i] = nl == 1 ? lo : (float) (lo * Math.pow(hi / lo, i / (double) (nl - 1)));
        }
        StringBuilder lvs = new StringBuilder("Fırça boyları: ");
        for (float l : levels) lvs.append((int) l).append(' ');
        log(lvs.toString());
        if (M.size() >= 2 && wmax < wmin * 1.3f) log("UYARI: fırça boyu değişmiyor, sonuç kalın çıkar.");
        float sc = Math.max(1.5f, Math.min(3f, lo / 4f) * (q == 0 ? 1.5f : q == 1 ? 1f : 0.8f));
        int cw = (int) ((rr - rl) / sc), ch = (int) ((rb - rt) / sc);
        while ((long) cw * ch > 650000) {
            sc += 0.5f;
            cw = (int) ((rr - rl) / sc);
            ch = (int) ((rb - rt) / sc);
        }
        log("Çizgi film planı hazırlanıyor...");
        float sx = bmp.getWidth() / (img.right - img.left), sy = bmp.getHeight() / (img.bottom - img.top);
        int bx = Math.max(0, Math.round((rl - img.left) * sx));
        int by = Math.max(0, Math.round((rt - img.top) * sy));
        int bw = Math.max(1, Math.min(bmp.getWidth() - bx, Math.round((rr - rl) * sx)));
        int bh = Math.max(1, Math.min(bmp.getHeight() - by, Math.round((rb - rt) * sy)));
        Bitmap crop = Bitmap.createBitmap(bmp, bx, by, bw, bh);
        Bitmap small = Bitmap.createScaledBitmap(crop, cw, ch, true);
        int[] px = pixels(small);
        int[] pal = new int[ents.size()];
        for (int i = 0; i < pal.length; i++) pal[i] = ents.get(i).rgb;
        List<LineArt.Item> raw = LineArt.plan(px, cw, ch, sc, pal, levels, 12000);
        // aynı renkteki ardışık öğeleri fırça seviyesine göre sırala (kaydırıcı hareketini azaltır)
        List<LineArt.Item> items = new ArrayList<>();
        int a = 0;
        while (a < raw.size()) {
            int b = a;
            while (b < raw.size() && raw.get(b).color == raw.get(a).color) b++;
            List<LineArt.Item> seg = new ArrayList<>(raw.subList(a, b));
            java.util.Collections.sort(seg, (p1, p2) -> p2.level - p1.level);
            items.addAll(seg);
            a = b;
        }
        int total = items.size();
        log("Plan: " + total + " parça, " + nl + " fırça boyu");
        int done = 0;
        int i = 0;
        while (i < total && !stop) {
            LineArt.Item s0 = items.get(i);
            int color = s0.color, lv = s0.level;
            setF(w2f(levels[lv]));
            selectEnt(color);
            List<float[]> batch = new ArrayList<>();
            while (i < total && !stop) {
                LineArt.Item s = items.get(i);
                if (s.color != color || s.level != lv) break;
                float[] pts = new float[s.pts.length];
                for (int k = 0; k < pts.length; k += 2) {
                    pts[k] = rl + s.pts[k];
                    pts[k + 1] = rt + s.pts[k + 1];
                }
                batch.add(pts);
                i++;
                if (batch.size() >= 10) {
                    polyBatch(batch);
                    done += batch.size();
                    batch.clear();
                    log("Çiziliyor: " + done + "/" + total);
                }
            }
            if (!batch.isEmpty()) {
                polyBatch(batch);
                done += batch.size();
            }
        }
        log(stop ? "Durduruldu." : "Bitti (" + done + " parça). Göndermeyi sen yap.");
    }

    // ---------------- Birebir mod: tek ince fırça + kontrol/onarım ----------------
    int farthestEnt(int rgb) {
        int best = 0, bd = -1;
        for (int i = 0; i < ents.size(); i++) {
            int d = cd(ents.get(i).rgb, rgb);
            if (d > bd) {
                bd = d;
                best = i;
            }
        }
        return best;
    }

    /** En ince fırçanın kalınlığını, çizimden önce/sonra ekran görüntüsü farkıyla ölçer. */
    float measureBrush(float rl, float rt, float rr, float rb) {
        float fallback = Math.max(8f, sw * 0.008f);
        float xm = (rl + rr) / 2, y = (rt + rb) / 2;
        float half = Math.min(100f, (rr - rl) * 0.3f);
        Bitmap before = shot();
        if (before == null) return fallback;
        int bp = before.getPixel((int) xm, (int) y);
        selectEnt(farthestEnt(bp));
        List<float[]> one = new ArrayList<>();
        one.add(new float[]{xm - half, y, xm + half, y});
        strokeBatch(one);
        Bitmap after = shot();
        if (after == null) {
            before.recycle();
            return fallback;
        }
        int n = 0;
        int cxm = (int) xm, cym = (int) y;
        for (int yy = cym; yy >= 0 && cd(after.getPixel(cxm, yy), before.getPixel(cxm, yy)) > 60; yy--) n++;
        for (int yy = cym + 1; yy < after.getHeight()
            && cd(after.getPixel(cxm, yy), before.getPixel(cxm, yy)) > 60; yy++) n++;
        before.recycle();
        after.recycle();
        if (n < 3 || n > 150) {
            log("Fırça ölçülemedi (" + n + "), varsayılan " + (int) fallback);
            return fallback;
        }
        return n;
    }

    void drawItems(List<LineArt.Item> items, float rl, float rt) {
        int total = items.size();
        int i = 0, done = 0;
        while (i < total && !stop) {
            int color = items.get(i).color;
            selectEnt(color);
            List<float[]> batch = new ArrayList<>();
            while (i < total && !stop && items.get(i).color == color) {
                float[] src = items.get(i).pts;
                float[] pts = new float[src.length];
                for (int k = 0; k < pts.length; k += 2) {
                    pts[k] = rl + src[k];
                    pts[k + 1] = rt + src[k + 1];
                }
                batch.add(pts);
                i++;
                if (batch.size() >= 10) {
                    polyBatch(batch);
                    done += batch.size();
                    batch.clear();
                    if (done % 100 == 0) log("Çiziliyor: " + done + "/" + total);
                }
            }
            if (!batch.isEmpty()) {
                polyBatch(batch);
                done += batch.size();
            }
        }
    }

    void runExact(Bitmap bmp, RectF img, float rl, float rt, float rr, float rb, int q, boolean enh) {
        if (slider != null) setF(0f);
        float W = measureBrush(rl, rt, rr, rb);
        log("En ince fırça: " + (int) W + " px");
        float sc = Math.max(1.5f, W / (q == 0 ? 2f : q == 1 ? 2.5f : 3f));
        int cw = (int) ((rr - rl) / sc), ch = (int) ((rb - rt) / sc);
        while ((long) cw * ch > 900000) {
            sc += 0.5f;
            cw = (int) ((rr - rl) / sc);
            ch = (int) ((rb - rt) / sc);
        }
        float sx = bmp.getWidth() / (img.right - img.left), sy = bmp.getHeight() / (img.bottom - img.top);
        int bx = Math.max(0, Math.round((rl - img.left) * sx));
        int by = Math.max(0, Math.round((rt - img.top) * sy));
        int bw = Math.max(1, Math.min(bmp.getWidth() - bx, Math.round((rr - rl) * sx)));
        int bh = Math.max(1, Math.min(bmp.getHeight() - by, Math.round((rb - rt) * sy)));
        Bitmap crop = Bitmap.createBitmap(bmp, bx, by, bw, bh);
        Bitmap small = Bitmap.createScaledBitmap(crop, cw, ch, true);
        int[] px = pixels(small);
        if (!lineMode && enh) Planner.enhance(px, cw, ch);
        int[] pal = new int[ents.size()];
        for (int i = 0; i < pal.length; i++) pal[i] = ents.get(i).rgb;
        int[] T = LineArt.quantize(px, cw, ch, pal);
        List<LineArt.Item> items = Raster.plan(T, cw, ch, sc, W, pal.length, 1, 30000);
        log("Plan: " + items.size() + " vuruş");
        drawItems(items, rl, rt);

        for (int it = 0; it < 3 && !stop; it++) {
            Bitmap b = shot();
            if (b == null) break;
            int w = b.getWidth(), h = b.getHeight();
            int[] sp = pixels(b);
            b.recycle();
            int[] T2 = new int[cw * ch];
            int bad = 0;
            for (int j = 0; j < ch; j++) {
                for (int i = 0; i < cw; i++) {
                    T2[j * cw + i] = -1;
                    int t = T[j * cw + i];
                    if (t < 0) continue;
                    int px0 = (int) (rl + (i + 0.5f) * sc), py0 = (int) (rt + (j + 0.5f) * sc);
                    if (px0 < 0 || py0 < 0 || px0 >= w || py0 >= h) continue;
                    if (slider != null && Math.abs(px0 - slider.x) < 36 && py0 > slider.yTop - 30
                        && py0 < slider.yBottom + 30) continue;
                    if (cd(sp[py0 * w + px0], pal[t]) > 80) {
                        T2[j * cw + i] = t;
                        bad++;
                    }
                }
            }
            log("Kontrol " + (it + 1) + ": " + bad + " hücre farklı");
            if (bad < cw * ch * 0.001) break;
            List<LineArt.Item> fix = Raster.plan(T2, cw, ch, sc, W, pal.length, 2, 15000);
            if (fix.size() < 5) break;
            drawItems(fix, rl, rt);
        }
        log(stop ? "Durduruldu." : "Bitti. Göndermeyi sen yap.");
    }
}
