package com.wex1n.draw;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class DrawService extends AccessibilityService {
    static final String IG = "com.instagram.android";
    static final String[] STEPS = {
        "Fırça boyutu çubuğunun EN ÜST ucuna dokunacaksın",
        "Fırça boyutu çubuğunun EN ALT ucuna dokunacaksın",
        "Paleti en SOLA kaydır. KIRMIZI renge dokunacaksın",
        "Aynı konumda AÇIK PEMBE renge dokunacaksın",
        "Aynı konumda PEACH (açık turuncu) renge dokunacaksın",
        "Paleti en SAĞA kaydır. SİYAH renge dokunacaksın",
        "Aynı konumda BEYAZ renge dokunacaksın (yoksa en açık renk)",
        "Üst araç çubuğunda 1. ikona (kalem) dokunacaksın",
        "Üst araç çubuğunda 4. ikona (neon) dokunacaksın",
        "Çizim alanının SOL ÜST köşesine dokunacaksın",
        "Çizim alanının SAĞ ALT köşesine (palet çubuğunun hemen üstü) dokunacaksın"
    };
    // referans renkler ve hangi kalibrasyon noktasına karşılık geldikleri
    static final int[][] REF = {{254, 216, 179}, {233, 0, 19}, {255, 206, 208}, {38, 38, 38}, {255, 255, 255}};
    static final int[] PIDX = {4, 2, 3, 5, 6};
    static final boolean[] AT_END = {false, false, false, true, true};

    final Handler main = new Handler(Looper.getMainLooper());
    WindowManager wm;
    LinearLayout panel;
    TextView logView;
    Button bReady;
    SharedPreferences sp;
    int sw, sh;
    float[][] P = new float[STEPS.length][2];
    int step = 0;
    volatile boolean stop = false;
    volatile boolean running = false;
    boolean calibrating = false;
    final List<String> logs = new ArrayList<>();
    int palView = 0; // 0 bilinmiyor, 1 baş, 2 son
    float curF = -1;
    List<float[]> M = new ArrayList<>();

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        sp = getSharedPreferences("cal", 0);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Rect b = wm.getMaximumWindowMetrics().getBounds();
        sw = b.width();
        sh = b.height();
        loadCal();
        buildPanel();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (panel == null || running || calibrating) return;
        CharSequence cs = e.getPackageName();
        if (cs == null) return;
        String pkg = cs.toString();
        if (pkg.equals(getPackageName())) return;
        if (pkg.equals(IG)) {
            panel.setVisibility(View.VISIBLE);
        } else if (!pkg.contains("systemui") && !pkg.contains("inputmethod") && !pkg.contains("keyboard")) {
            panel.setVisibility(View.GONE);
        }
    }

    @Override
    public void onInterrupt() {
        stop = true;
    }

    // ---------------- UI ----------------
    Button mk(String t, View.OnClickListener c) {
        Button b = new Button(this);
        b.setText(t);
        b.setTextSize(11);
        b.setAllCaps(false);
        b.setPadding(8, 0, 8, 0);
        b.setOnClickListener(c);
        return b;
    }

    void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xCC000000);
        panel.setPadding(10, 6, 10, 6);
        LinearLayout row = new LinearLayout(this);
        row.addView(mk("Kalibre", v -> startCalibration()));
        row.addView(mk("ÇİZ", v -> startDraw()));
        row.addView(mk("Dur", v -> stop = true));
        bReady = mk("Hazır", v -> showCapture());
        bReady.setVisibility(View.GONE);
        row.addView(bReady);
        logView = new TextView(this);
        logView.setTextColor(0xFFFFFFFF);
        logView.setTextSize(11);
        panel.addView(row);
        panel.addView(logView);
        panel.setVisibility(View.GONE);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            (int) (sw * 0.7), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(panel, lp);
    }

    void log(String m) {
        synchronized (logs) {
            logs.add(m);
            while (logs.size() > 5) logs.remove(0);
        }
        main.post(() -> {
            StringBuilder sb = new StringBuilder();
            synchronized (logs) {
                for (String s : logs) sb.append(s).append('\n');
            }
            logView.setText(sb.toString().trim());
        });
    }

    // ---------------- Kalibrasyon ----------------
    void loadCal() {
        String s = sp.getString("pts", null);
        if (s == null) return;
        String[] a = s.split(",");
        if (a.length != STEPS.length * 2) return;
        for (int i = 0; i < STEPS.length; i++) {
            P[i][0] = Float.parseFloat(a[2 * i]);
            P[i][1] = Float.parseFloat(a[2 * i + 1]);
        }
    }

    void startCalibration() {
        if (running) return;
        calibrating = true;
        step = 0;
        askStep();
    }

    void askStep() {
        if (step >= STEPS.length) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < STEPS.length; i++) {
                if (i > 0) sb.append(',');
                sb.append(P[i][0]).append(',').append(P[i][1]);
            }
            sp.edit().putString("pts", sb.toString()).apply();
            bReady.setVisibility(View.GONE);
            calibrating = false;
            log("Kalibrasyon tamam. Çizim ekranındayken ÇİZ'e bas.");
            return;
        }
        bReady.setVisibility(View.VISIBLE);
        log((step + 1) + "/" + STEPS.length + ": " + STEPS[step] + ". Hazırsan 'Hazır'a bas.");
    }

    void showCapture() {
        final View v = new View(this);
        v.setBackgroundColor(0x22FFFFFF);
        v.setOnTouchListener((vv, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                P[step][0] = e.getRawX();
                P[step][1] = e.getRawY();
                wm.removeView(v);
                step++;
                main.postDelayed(this::askStep, 200);
            }
            return true;
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        wm.addView(v, lp);
    }

    // ---------------- Dokunuş yardımcıları ----------------
    float cx(float x) {
        return Math.max(1, Math.min(sw - 2, x));
    }

    float cy(float y) {
        return Math.max(1, Math.min(sh - 2, y));
    }

    boolean gesture(Path path, long dur) {
        final CountDownLatch l = new CountDownLatch(1);
        final boolean[] ok = {false};
        final long d = Math.max(1, Math.min(59000, dur));
        final GestureDescription g = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path, 0, d)).build();
        main.post(() -> {
            boolean r = dispatchGesture(g, new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gd) {
                    ok[0] = true;
                    l.countDown();
                }

                @Override
                public void onCancelled(GestureDescription gd) {
                    l.countDown();
                }
            }, null);
            if (!r) l.countDown();
        });
        try {
            l.await(d + 5000, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            // yoksay
        }
        sleep(30);
        return ok[0];
    }

    void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            // yoksay
        }
    }

    void tap(float x, float y) {
        Path p = new Path();
        p.moveTo(cx(x), cy(y));
        gesture(p, 60);
    }

    void drag(float x1, float y1, float x2, float y2, long dur) {
        Path p = new Path();
        p.moveTo(cx(x1), cy(y1));
        float ex = cx(x2), ey = cy(y2);
        if (Math.abs(ex - cx(x1)) < 1 && Math.abs(ey - cy(y1)) < 1) ey += 1;
        p.lineTo(ex, ey);
        gesture(p, dur);
    }

    void stroke(List<float[]> pts) {
        if (pts.isEmpty()) return;
        Path p = new Path();
        float[] a = pts.get(0);
        p.moveTo(cx(a[0]), cy(a[1]));
        float len = 0;
        float px = cx(a[0]), py = cy(a[1]);
        if (pts.size() == 1) {
            p.lineTo(px + 1, py);
            len = 1;
        }
        for (int i = 1; i < pts.size(); i++) {
            float x = cx(pts.get(i)[0]), y = cy(pts.get(i)[1]);
            p.lineTo(x, y);
            len += (float) Math.hypot(x - px, y - py);
            px = x;
            py = y;
        }
        gesture(p, (long) Math.max(60, Math.min(55000, len / 1.1f)));
    }

    // ---------------- Araç / renk / boyut ----------------
    void flingPalette(boolean toEnd) {
        float y = 0;
        for (int i = 2; i <= 6; i++) y += P[i][1];
        y /= 5;
        for (int i = 0; i < 3; i++) {
            if (toEnd) drag(sw * 0.88f, y, sw * 0.12f, y, 140);
            else drag(sw * 0.12f, y, sw * 0.88f, y, 140);
            sleep(120);
        }
        palView = toEnd ? 2 : 1;
    }

    void selectColor(int[] rgb) {
        int best = 0;
        double bd = 1e9;
        for (int i = 0; i < REF.length; i++) {
            double d = Math.hypot(Math.hypot(rgb[0] - REF[i][0], rgb[1] - REF[i][1]), rgb[2] - REF[i][2]);
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
        int need = AT_END[best] ? 2 : 1;
        if (palView != need) flingPalette(need == 2);
        tap(P[PIDX[best]][0], P[PIDX[best]][1]);
    }

    void selectTool(int t) {
        int idx = (t == 3) ? 8 : 7;
        tap(P[idx][0], P[idx][1]);
        palView = 0;
    }

    void setF(float f) {
        if (Math.abs(f - curF) < 0.02f) return;
        float x = P[0][0], yT = P[0][1], yB = P[1][1];
        float y = yB + (yT - yB) * f;
        if (curF < 0) {
            drag(x, yB + (yT - yB) * 0.5f, x, y, 300);
            drag(x, yB + (yT - yB) * 0.85f, x, y, 300);
        } else {
            drag(x, yB + (yT - yB) * curF, x, y, 300);
        }
        curF = f;
    }

    float w2f(float w) {
        List<float[]> a = new ArrayList<>(M);
        Collections.sort(a, new Comparator<float[]>() {
            @Override
            public int compare(float[] p, float[] q) {
                return Float.compare(p[1], q[1]);
            }
        });
        if (w <= a.get(0)[1]) return a.get(0)[0];
        for (int i = 1; i < a.size(); i++) {
            if (w <= a.get(i)[1]) {
                float f0 = a.get(i - 1)[0], w0 = a.get(i - 1)[1], f1 = a.get(i)[0], w1 = a.get(i)[1];
                return w1 == w0 ? f1 : f0 + (f1 - f0) * (w - w0) / (w1 - w0);
            }
        }
        return a.get(a.size() - 1)[0];
    }

    // ---------------- Ekran görüntüsü ile kalınlık ölçümü ----------------
    Bitmap shot() {
        final Bitmap[] out = new Bitmap[1];
        final CountDownLatch l = new CountDownLatch(1);
        main.post(() -> takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override
            public void onSuccess(ScreenshotResult r) {
                try {
                    Bitmap hw = Bitmap.wrapHardwareBuffer(r.getHardwareBuffer(), r.getColorSpace());
                    out[0] = hw.copy(Bitmap.Config.ARGB_8888, false);
                    r.getHardwareBuffer().close();
                } catch (Throwable t) {
                    out[0] = null;
                }
                l.countDown();
            }

            @Override
            public void onFailure(int code) {
                l.countDown();
            }
        }));
        try {
            l.await(4, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            // yoksay
        }
        return out[0];
    }

    boolean near(int a, int b) {
        int d = Math.abs(((a >> 16) & 255) - ((b >> 16) & 255)) + Math.abs(((a >> 8) & 255) - ((b >> 8) & 255))
            + Math.abs((a & 255) - (b & 255));
        return d < 70;
    }

    float measure(Bitmap b, int x, int y) {
        if (x < 0 || y < 0 || x >= b.getWidth() || y >= b.getHeight()) return -1;
        int ref = b.getPixel(x, y);
        int n = 1;
        for (int yy = y - 1; yy >= 0 && near(b.getPixel(x, yy), ref); yy--) n++;
        for (int yy = y + 1; yy < b.getHeight() && near(b.getPixel(x, yy), ref); yy++) n++;
        return n;
    }

    // ---------------- Çizim ----------------
    void startDraw() {
        if (running) return;
        if (sp.getString("pts", null) == null) {
            log("Önce Kalibre'ye bas.");
            return;
        }
        loadCal();
        stop = false;
        running = true;
        new Thread(() -> {
            try {
                runDraw();
            } catch (Throwable e) {
                log("HATA: " + e);
            } finally {
                running = false;
            }
        }).start();
    }

    String readAsset(String name) throws Exception {
        InputStream in = getAssets().open(name);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    void runDraw() throws Exception {
        JSONObject D = new JSONObject(readAsset("drawing.json"));
        double W = D.getDouble("W"), H = D.getDouble("H");
        JSONArray L = D.getJSONArray("L");
        float left = Math.min(P[9][0], P[10][0]), right = Math.max(P[9][0], P[10][0]);
        float top = Math.min(P[9][1], P[10][1]), bottom = Math.max(P[9][1], P[10][1]);
        palView = 0;
        curF = -1;
        M = new ArrayList<>();

        log("Fırça ölçülüyor...");
        selectTool(0);
        selectColor(new int[]{38, 38, 38});
        float xm = (left + right) / 2;
        float[] fs = {0, 0.25f, 0.5f, 0.75f, 1};
        for (int i = 0; i < 5 && !stop; i++) {
            setF(fs[i]);
            float y = top + (bottom - top) * (i + 0.7f) / 5.4f;
            List<float[]> pts = new ArrayList<>();
            pts.add(new float[]{xm - 120, y});
            pts.add(new float[]{xm + 120, y});
            stroke(pts);
            sleep(300);
            Bitmap b = shot();
            if (b != null) {
                float w = measure(b, (int) xm, (int) y);
                b.recycle();
                if (w > 2) M.add(new float[]{fs[i], w});
            }
        }
        if (M.size() < 2) {
            M.clear();
            M.add(new float[]{0, sw * 0.012f});
            M.add(new float[]{1, sw * 0.2f});
            log("Ölçüm olmadı, varsayılan boyutlar.");
        } else {
            StringBuilder sb = new StringBuilder("Boyut: ");
            for (float[] m : M) sb.append(m[0]).append('=').append((int) m[1]).append(' ');
            log(sb.toString());
        }
        float wmax = 0, fmax = 1;
        for (float[] m : M) {
            if (m[1] > wmax) {
                wmax = m[1];
                fmax = m[0];
            }
        }

        float s = (float) Math.min((right - left) / W, (bottom - top) / H);
        float ox = left + ((right - left) - (float) W * s) / 2;
        float oy = top + (bottom - top) - (float) H * s;

        log("Arka plan boyanıyor...");
        selectTool(0);
        selectColor(new int[]{254, 216, 179});
        setF(fmax);
        List<float[]> bg = new ArrayList<>();
        float step = wmax * 0.8f;
        boolean flip = false;
        for (float y = top - wmax / 3; y <= bottom + wmax / 2 && !stop; y += step) {
            float xa = left - wmax / 3, xb = right + wmax / 3;
            if (flip) {
                bg.add(new float[]{xb, y});
                bg.add(new float[]{xa, y});
            } else {
                bg.add(new float[]{xa, y});
                bg.add(new float[]{xb, y});
            }
            flip = !flip;
        }
        stroke(bg);

        log("Şekiller çiziliyor...");
        int curTool = 0, done = 0;
        for (int i = 0; i < L.length() && !stop; i++) {
            JSONArray l = L.getJSONArray(i);
            int tool = l.getInt(0);
            JSONArray c = l.getJSONArray(1);
            double w = l.getDouble(2);
            JSONArray pa = l.getJSONArray(3);
            if (tool != curTool) {
                selectTool(tool);
                curTool = tool;
            }
            selectColor(new int[]{c.getInt(0), c.getInt(1), c.getInt(2)});
            setF(w2f((float) (w * s)));
            List<float[]> pts = new ArrayList<>();
            for (int k = 0; k + 1 < pa.length(); k += 2) {
                pts.add(new float[]{ox + (float) pa.getDouble(k) * s, oy + (float) pa.getDouble(k + 1) * s});
            }
            stroke(pts);
            done++;
        }
        log(stop ? "Durduruldu." : "Bitti (" + done + " darbe). Göndermeyi sen yap.");
    }
}
