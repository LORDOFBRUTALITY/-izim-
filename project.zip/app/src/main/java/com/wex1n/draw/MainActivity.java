package com.wex1n.draw;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(40, 80, 40, 40);
        TextView t = new TextView(this);
        t.setTextSize(16);
        t.setText("Wex1n Çizim\n\n"
            + "1) Aşağıdaki ilk düğmeyle Erişilebilirlik ayarlarını aç, 'Wex1n Çizim'i bul ve aç.\n"
            + "(Android 13+ ta açılmıyorsa: ikinci düğme → ⋮ menü → 'Kısıtlı ayarlara izin ver', sonra tekrar dene.)\n\n"
            + "2) Instagram'da DM'e gir, çizim ekranını aç. Sol üstte küçük bir panel çıkar.\n\n"
            + "3) Panelde 'Kalibre'ye bas, adımları takip et (sadece bir kez gerekir).\n\n"
            + "4) 'ÇİZ'e bas. Durdurmak için 'Dur'. Bitince göndermeyi sen yap.");
        Button b1 = new Button(this);
        b1.setText("Erişilebilirlik ayarlarını aç");
        b1.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        Button b2 = new Button(this);
        b2.setText("Uygulama bilgisi (kısıtlı ayar izni)");
        b2.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:" + getPackageName()))));
        l.addView(t);
        l.addView(b1);
        l.addView(b2);
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        setContentView(sv);
    }
}
