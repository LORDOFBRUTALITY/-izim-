package com.wex1n.draw;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Ekran görüntüsünden Instagram çizim arayüzünü bulur (saf Java, piksel dizisi üzerinde). */
public class Detect {
    public static class Sw {
        public int x, y, rgb;
        public Sw(int x, int y, int rgb) {
            this.x = x;
            this.y = y;
            this.rgb = rgb;
        }
    }

    public static class Pal {
        public List<Sw> sw = new ArrayList<>();
        public int y, left, right;
    }

    public static class Slider {
        public int x, yTop, yBottom, knobY;
    }

    static int cdiff(int a, int b) {
        return Math.abs(((a >> 16) & 255) - ((b >> 16) & 255)) + Math.abs(((a >> 8) & 255) - ((b >> 8) & 255))
            + Math.abs((a & 255) - (b & 255));
    }

    static int luma(int c) {
        return (((c >> 16) & 255) * 30 + ((c >> 8) & 255) * 59 + (c & 255) * 11) / 100;
    }

    static List<int[]> runsAt(int[] px, int w, int y) {
        List<int[]> out = new ArrayList<>();
        int st = 0;
        int c0 = px[y * w];
        for (int x = 1; x < w; x++) {
            int c = px[y * w + x];
            if (cdiff(c, c0) > 60) {
                out.add(new int[]{st, x - 1, px[y * w + (st + x - 1) / 2]});
                st = x;
                c0 = c;
            }
        }
        out.add(new int[]{st, w - 1, px[y * w + (st + w - 1) / 2]});
        return out;
    }

    static Pal buildAt(int[] px, int w, int y) {
        List<int[]> all = runsAt(px, w, y);
        int bgc = all.get(0)[2], bgw = 0;
        for (int[] r : all) {
            int wd = r[1] - r[0] + 1;
            if (wd > bgw) {
                bgw = wd;
                bgc = r[2];
            }
        }
        List<int[]> c = new ArrayList<>();
        for (int[] r : all) {
            int wd = r[1] - r[0] + 1;
            if (wd >= 18 && wd <= 110 && cdiff(r[2], bgc) > 40) c.add(r);
        }
        if (c.size() < 6) return null;
        int[] ds = new int[c.size() - 1];
        for (int i = 0; i + 1 < c.size(); i++) ds[i] = center(c.get(i + 1)) - center(c.get(i));
        int[] sd = ds.clone();
        Arrays.sort(sd);
        int pitch = sd[sd.length / 2];
        int bestS = 0, bestL = 0, st0 = 0;
        for (int i = 0; i < c.size(); i++) {
            if (!(i > 0 && Math.abs(ds[i - 1] - pitch) <= Math.max(5, pitch * 0.12))) st0 = i;
            if (i - st0 + 1 > bestL) {
                bestL = i - st0 + 1;
                bestS = st0;
            }
        }
        if (bestL < 6) return null;
        Pal p = new Pal();
        for (int i = bestS; i < bestS + bestL; i++) {
            int cx = center(c.get(i));
            p.sw.add(new Sw(cx, y, avg(px, w, cx, y)));
        }
        p.y = y;
        p.left = c.get(0)[0];
        p.right = c.get(c.size() - 1)[1];
        return p;
    }

    /** Alt paletteki renk dairelerini bulur (satırın dikey merkezinde). */
    public static Pal palette(int[] px, int w, int h) {
        int maxN = 0, minL = Integer.MAX_VALUE, maxR = 0;
        List<Integer> rows = new ArrayList<>();
        List<Integer> counts = new ArrayList<>();
        for (int y = (int) (h * 0.80); y < (int) (h * 0.98); y += 2) {
            Pal p = buildAt(px, w, y);
            int n = p == null ? 0 : p.sw.size();
            rows.add(y);
            counts.add(n);
            if (p != null) {
                minL = Math.min(minL, p.left);
                maxR = Math.max(maxR, p.right);
            }
            maxN = Math.max(maxN, n);
        }
        if (maxN < 6) return null;
        List<Integer> good = new ArrayList<>();
        for (int i = 0; i < rows.size(); i++) if (counts.get(i) >= maxN - 1) good.add(rows.get(i));
        int y = good.get(good.size() / 2);
        Pal p = buildAt(px, w, y);
        if (p == null) return null;
        p.left = minL;
        p.right = maxR;
        return p;
    }

    static int center(int[] r) {
        return (r[0] + r[1]) / 2;
    }

    static int avg(int[] px, int w, int cx, int cy) {
        int r = 0, g = 0, b = 0, n = 0;
        for (int dy = -2; dy <= 2; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                int c = px[(cy + dy) * w + cx + dx];
                r += (c >> 16) & 255;
                g += (c >> 8) & 255;
                b += c & 255;
                n++;
            }
        }
        return 0xFF000000 | ((r / n) << 16) | ((g / n) << 8) | (b / n);
    }

    /**
     * Soldaki dikey fırça boyutu çizgisini bulur: çevresinden belirgin farklı, uzun, dikey bir çizgi.
     * left..left+maxDx aralığında arar.
     */
    static boolean diffAt(int[] px, int w, int x, int y) {
        int l = luma(px[y * w + x]);
        int nb = (luma(px[y * w + x - 12]) + luma(px[y * w + x + 12])) / 2;
        return Math.abs(l - nb) > 28;
    }

    /** Soldaki dikey fırça boyutu çizgisi: ince, uzun, dikey çizgi. */
    public static Slider slider(int[] px, int w, int h, int left, int maxDx) {
        int y0 = (int) (h * 0.12), y1 = (int) (h * 0.92);
        int bestLen = 0, bx = -1, bTop = 0, bBot = 0;
        int x0 = Math.max(20, left), x1 = Math.min(w - 20, left + maxDx);
        for (int x = x0; x < x1; x++) {
            int run = 0, gap = 0, start = 0, last = 0;
            for (int y = y0; y < y1; y++) {
                boolean on = diffAt(px, w, x, y) && !diffAt(px, w, x - 4, y) && !diffAt(px, w, x + 4, y);
                if (on) {
                    if (run == 0) start = y;
                    run += 1 + gap;
                    gap = 0;
                    last = y;
                    if (run > bestLen) {
                        bestLen = run;
                        bx = x;
                        bTop = start;
                        bBot = last;
                    }
                } else if (run > 0) {
                    gap++;
                    if (gap > 60) {
                        run = 0;
                        gap = 0;
                    }
                }
            }
        }
        if (bestLen < 100) return null;
        Slider s = new Slider();
        s.x = bx;
        s.yTop = bTop;
        s.yBottom = bBot;
        int bestW = 0, ky = (bTop + bBot) / 2;
        for (int y = bTop; y <= bBot; y++) {
            int cnt = 0;
            for (int dx = -16; dx <= 16; dx++) {
                int xx = bx + dx;
                if (xx < 14 || xx >= w - 14) continue;
                if (diffAt(px, w, xx, y)) cnt++;
            }
            if (cnt > bestW) {
                bestW = cnt;
                ky = y;
            }
        }
        s.knobY = ky;
        return s;
    }

    public static class Tools {
        public int[] x = new int[5];
        public int y;
        public int selected = -1;
    }

    /** Üstteki 5 araç ikonunu bulur: halka (seçili değil) veya dolu daire (seçili). */
    public static Tools tools(int[] px, int w, int h, int left, int right) {
        int y0 = (int) (h * 0.035), y1 = (int) (h * 0.14);
        int bw = right - left + 1, bh = y1 - y0;
        boolean[] on = new boolean[bw * bh];
        for (int y = 0; y < bh; y++) {
            for (int x = 0; x < bw; x++) on[y * bw + x] = luma(px[(y0 + y) * w + left + x]) > 190;
        }
        boolean[] seen = new boolean[on.length];
        List<int[]> comps = new ArrayList<>(); // {cx, cy, w, h, area}
        int[] stack = new int[on.length];
        for (int i = 0; i < on.length; i++) {
            if (!on[i] || seen[i]) continue;
            int sp = 0;
            stack[sp++] = i;
            seen[i] = true;
            int minX = bw, maxX = 0, minY = bh, maxY = 0, area = 0;
            while (sp > 0) {
                int p = stack[--sp];
                int px0 = p % bw, py0 = p / bw;
                area++;
                if (px0 < minX) minX = px0;
                if (px0 > maxX) maxX = px0;
                if (py0 < minY) minY = py0;
                if (py0 > maxY) maxY = py0;
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = px0 + dx, ny = py0 + dy;
                        if (nx < 0 || ny < 0 || nx >= bw || ny >= bh) continue;
                        int q = ny * bw + nx;
                        if (on[q] && !seen[q]) {
                            seen[q] = true;
                            stack[sp++] = q;
                        }
                    }
                }
            }
            int cw = maxX - minX + 1, chh = maxY - minY + 1;
            if (cw >= 36 && cw <= 110 && Math.abs(cw - chh) <= 8) {
                comps.add(new int[]{left + (minX + maxX) / 2, y0 + (minY + maxY) / 2, cw, chh, area});
            }
        }
        // aynı satırda, düzenli aralıklı 5 daire
        for (int[] a : comps) {
            List<int[]> row = new ArrayList<>();
            for (int[] b : comps) if (Math.abs(b[1] - a[1]) <= 6) row.add(b);
            if (row.size() < 5) continue;
            row.sort((p, q) -> p[0] - q[0]);
            for (int s0 = 0; s0 + 5 <= row.size(); s0++) {
                double pitch = (row.get(s0 + 4)[0] - row.get(s0)[0]) / 4.0;
                boolean ok = pitch > 40;
                for (int k = 0; k < 5 && ok; k++) {
                    if (Math.abs(row.get(s0 + k)[0] - (row.get(s0)[0] + pitch * k)) > pitch * 0.12) ok = false;
                }
                if (!ok) continue;
                Tools t = new Tools();
                t.y = row.get(s0)[1];
                double best = -1;
                for (int k = 0; k < 5; k++) {
                    int[] c = row.get(s0 + k);
                    t.x[k] = c[0];
                    double fill = c[4] / (double) (c[2] * c[3]);
                    if (fill > best) {
                        best = fill;
                        t.selected = k;
                    }
                }
                if (best < 0.45) t.selected = -1; // hiçbiri dolu görünmüyor
                return t;
            }
        }
        return null;
    }
}
