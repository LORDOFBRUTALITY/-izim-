package com.wex1n.draw;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Ekran görüntüsünden Instagram çizim arayüzünü bulur (saf Java, piksel dizisi üzerinde). */
public class Detect {
    public static class Sw {
        public int x, y, rgb;
        public Sw(int x, int y, int rgb) {
            this.x = x;
            this.y = y;
            this.rgb = rgb;
        }
    }

    public static class Pal {
        public List<Sw> sw = new ArrayList<>();
        public int y, left, right;
    }

    public static class Slider {
        public int x, yTop, yBottom, knobY;
    }

    static int cdiff(int a, int b) {
        return Math.abs(((a >> 16) & 255) - ((b >> 16) & 255)) + Math.abs(((a >> 8) & 255) - ((b >> 8) & 255))
            + Math.abs((a & 255) - (b & 255));
    }

    static int luma(int c) {
        return (((c >> 16) & 255) * 30 + ((c >> 8) & 255) * 59 + (c & 255) * 11) / 100;
    }

    static List<int[]> runsAt(int[] px, int w, int y) {
        List<int[]> out = new ArrayList<>();
        int st = 0;
        int c0 = px[y * w];
        for (int x = 1; x < w; x++) {
            int c = px[y * w + x];
            if (cdiff(c, c0) > 60) {
                out.add(new int[]{st, x - 1, px[y * w + (st + x - 1) / 2]});
                st = x;
                c0 = c;
            }
        }
        out.add(new int[]{st, w - 1, px[y * w + (st + w - 1) / 2]});
        return out;
    }

    static Pal buildAt(int[] px, int w, int y) {
        List<int[]> all = runsAt(px, w, y);
        int bgc = all.get(0)[2], bgw = 0;
        for (int[] r : all) {
            int wd = r[1] - r[0] + 1;
            if (wd > bgw) {
                bgw = wd;
                bgc = r[2];
            }
        }
        List<int[]> c = new ArrayList<>();
        for (int[] r : all) {
            int wd = r[1] - r[0] + 1;
            if (wd >= 18 && wd <= 110 && cdiff(r[2], bgc) > 40) c.add(r);
        }
        if (c.size() < 6) return null;
        int[] ds = new int[c.size() - 1];
        for (int i = 0; i + 1 < c.size(); i++) ds[i] = center(c.get(i + 1)) - center(c.get(i));
        int[] sd = ds.clone();
        Arrays.sort(sd);
        int pitch = sd[sd.length / 2];
        int bestS = 0, bestL = 0, st0 = 0;
        for (int i = 0; i < c.size(); i++) {
            if (!(i > 0 && Math.abs(ds[i - 1] - pitch) <= Math.max(5, pitch * 0.12))) st0 = i;
            if (i - st0 + 1 > bestL) {
                bestL = i - st0 + 1;
                bestS = st0;
            }
        }
        if (bestL < 6) return null;
        Pal p = new Pal();
        for (int i = bestS; i < bestS + bestL; i++) {
            int cx = center(c.get(i));
            p.sw.add(new Sw(cx, y, avg(px, w, cx, y)));
        }
        p.y = y;
        p.left = c.get(0)[0];
        p.right = c.get(c.size() - 1)[1];
        return p;
    }

    /** Alt paletteki renk dairelerini bulur (satırın dikey merkezinde). */
    public static Pal palette(int[] px, int w, int h) {
        int maxN = 0, minL = Integer.MAX_VALUE, maxR = 0;
        List<Integer> rows = new ArrayList<>();
        List<Integer> counts = new ArrayList<>();
        for (int y = (int) (h * 0.80); y < (int) (h * 0.98); y += 2) {
            Pal p = buildAt(px, w, y);
            int n = p == null ? 0 : p.sw.size();
            rows.add(y);
            counts.add(n);
            if (p != null) {
                minL = Math.min(minL, p.left);
                maxR = Math.max(maxR, p.right);
            }
            maxN = Math.max(maxN, n);
        }
        if (maxN < 6) return null;
        List<Integer> good = new ArrayList<>();
        for (int i = 0; i < rows.size(); i++) if (counts.get(i) >= maxN - 1) good.add(rows.get(i));
        int y = good.get(good.size() / 2);
        Pal p = buildAt(px, w, y);
        if (p == null) return null;
        p.left = minL;
        p.right = maxR;
        return p;
    }

    static int center(int[] r) {
        return (r[0] + r[1]) / 2;
    }

    static int avg(int[] px, int w, int cx, int cy) {
        int r = 0, g = 0, b = 0, n = 0;
        for (int dy = -2; dy <= 2; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                int c = px[(cy + dy) * w + cx + dx];
                r += (c >> 16) & 255;
                g += (c >> 8) & 255;
                b += c & 255;
                n++;
            }
        }
        return 0xFF000000 | ((r / n) << 16) | ((g / n) << 8) | (b / n);
    }

    /**
     * Soldaki dikey fırça boyutu çizgisini bulur: çevresinden belirgin farklı, uzun, dikey bir çizgi.
     * left..left+maxDx aralığında arar.
     */
    static boolean diffAt(int[] px, int w, int x, int y) {
        int l = luma(px[y * w + x]);
        int nb = (luma(px[y * w + x - 12]) + luma(px[y * w + x + 12])) / 2;
        return Math.abs(l - nb) > 28;
    }

    /** Soldaki dikey fırça boyutu çizgisi: ince, uzun, dikey çizgi. */
    public static Slider slider(int[] px, int w, int h, int left, int maxDx) {
        int y0 = (int) (h * 0.12), y1 = (int) (h * 0.92);
        int bestLen = 0, bx = -1, bTop = 0, bBot = 0;
        int x0 = Math.max(20, left), x1 = Math.min(w - 20, left + maxDx);
        for (int x = x0; x < x1; x++) {
            int run = 0, gap = 0, start = 0, last = 0;
            for (int y = y0; y < y1; y++) {
                boolean on = diffAt(px, w, x, y) && !diffAt(px, w, x - 4, y) && !diffAt(px, w, x + 4, y);
                if (on) {
                    if (run == 0) start = y;
                    run += 1 + gap;
                    gap = 0;
                    last = y;
                    if (run > bestLen) {
                        bestLen = run;
                        bx = x;
                        bTop = start;
                        bBot = last;
                    }
                } else if (run > 0) {
                    gap++;
                    if (gap > 60) {
                        run = 0;
                        gap = 0;
                    }
                }
            }
        }
        if (bestLen < 100) return null;
        Slider s = new Slider();
        s.x = bx;
        s.yTop = bTop;
        s.yBottom = bBot;
        int bestW = 0, ky = (bTop + bBot) / 2;
        for (int y = bTop; y <= bBot; y++) {
            int cnt = 0;
            for (int dx = -16; dx <= 16; dx++) {
                int xx = bx + dx;
                if (xx < 14 || xx >= w - 14) continue;
                if (diffAt(px, w, xx, y)) cnt++;
            }
            if (cnt > bestW) {
                bestW = cnt;
                ky = y;
            }
        }
        s.knobY = ky;
        return s;
    }
}
