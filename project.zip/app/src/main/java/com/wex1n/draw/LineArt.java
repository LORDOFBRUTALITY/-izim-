package com.wex1n.draw;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Çizgi film / illüstrasyon modu: renkli alanları dolgu ile, siyah ince çizgileri iskelet izleyerek çizer.
 * Saf Java.
 */
public class LineArt {
    public static class Item {
        public int color;
        public int level;      // fırça seviyesi indeksi (levels[level])
        public float[] pts;    // x0,y0,x1,y1,... (resmin sol-üstüne göre ekran pikseli)
    }

    static final int[] N8X = {-1, 0, 1, -1, 1, -1, 0, 1};
    static final int[] N8Y = {-1, -1, -1, 0, 0, 1, 1, 1};

    /**
     * @param img    ARGB, cw x ch hücre
     * @param sc     hücre başına ekran pikseli
     * @param pal    palet RGB
     * @param levels kullanılabilir fırça çapları (ekran px), küçükten büyüğe
     */
    public static List<Item> plan(int[] img, int cw, int ch, float sc, int[] pal, float[] levels, int maxItems) {
        int n = cw * ch, np = pal.length;
        float[][] pl = new float[np][];
        boolean[] ink = new boolean[np];
        boolean[] neutral = new boolean[np];
        for (int i = 0; i < np; i++) {
            double[] l = Planner.lab(pal[i]);
            pl[i] = new float[]{(float) l[0], (float) l[1], (float) l[2]};
            ink[i] = l[0] < 42;
            neutral[i] = Math.hypot(l[1], l[2]) < 14;
        }
        // 1) paletteye nicemle
        int[] idx = new int[n];
        for (int i = 0; i < n; i++) {
            int c = img[i];
            if (((c >>> 24) & 255) < 128) {
                idx[i] = -1;
                continue;
            }
            double[] l = Planner.lab(c);
            boolean neut = Math.hypot(l[1], l[2]) < 12;
            int best = -1;
            double bd = 1e18;
            for (int p = 0; p < np; p++) {
                if (neut && !neutral[p]) continue;
                double dl = l[0] - pl[p][0], da = l[1] - pl[p][1], db = l[2] - pl[p][2];
                double d = dl * dl + da * da + db * db;
                if (d < bd) {
                    bd = d;
                    best = p;
                }
            }
            idx[i] = best;
        }
        idx = mode3(idx, cw, ch, np);

        // 2) alt katman: mürekkep piksellerine en yakın mürekkepsiz rengi ver
        boolean[] isInk = new boolean[n];
        int[] under = new int[n];
        int[] queue = new int[n];
        int qh = 0, qt = 0;
        for (int i = 0; i < n; i++) {
            if (idx[i] < 0) {
                under[i] = -1;
                continue;
            }
            if (ink[idx[i]]) {
                isInk[i] = true;
                under[i] = -2;
            } else {
                under[i] = idx[i];
                queue[qt++] = i;
            }
        }
        while (qh < qt) {
            int p = queue[qh++];
            int x = p % cw, y = p / cw;
            for (int k = 0; k < 8; k += 1) {
                int nx = x + N8X[k], ny = y + N8Y[k];
                if (nx < 0 || ny < 0 || nx >= cw || ny >= ch) continue;
                int q = ny * cw + nx;
                if (under[q] == -2) {
                    under[q] = under[p];
                    queue[qt++] = q;
                }
            }
        }
        for (int i = 0; i < n; i++) if (under[i] == -2) under[i] = -1; // hiç mürekkepsiz piksel yoksa

        // mürekkep rengi: en çok kullanılan koyu palet rengi
        int[] inkCount = new int[np];
        for (int i = 0; i < n; i++) if (isInk[i]) inkCount[idx[i]]++;
        int inkColor = -1;
        for (int p = 0; p < np; p++) if (ink[p] && (inkColor < 0 || inkCount[p] > inkCount[inkColor])) inkColor = p;
        if (inkColor < 0) {
            float bl = 1e9f;
            for (int p = 0; p < np; p++) if (pl[p][0] < bl) {
                bl = pl[p][0];
                inkColor = p;
            }
        }

        List<Item> out = new ArrayList<>();
        int[] area = new int[np];
        for (int i = 0; i < n; i++) if (under[i] >= 0) area[under[i]]++;
        Integer[] order = new Integer[np];
        for (int i = 0; i < np; i++) order[i] = i;
        final int[] ar = area;
        Arrays.sort(order, new Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                return ar[b] - ar[a];
            }
        });

        // 3) renkli alanları kapsama (coverage) yöntemiyle doldur
        for (int oi = 0; oi < np; oi++) {
            int c = order[oi];
            if (area[c] < 4) continue;
            boolean[] region = new boolean[n];
            for (int i = 0; i < n; i++) region[i] = under[i] == c;
            cover(region, cw, ch, sc, levels, 0, c, out, maxItems);
            if (out.size() >= maxItems) return out;
        }

        // 4) ince çizgi genişliği tahmini ve kalın mürekkep alanları
        float[] dtInk = dist(isInk, cw, ch);
        boolean[] covered = new boolean[n];
        float lineW = medianSkeletonWidth(isInk, dtInk, cw, ch) * sc;
        int fatFrom = levels.length;
        for (int k = 0; k < levels.length; k++) {
            if (levels[k] >= 1.7f * lineW) {
                fatFrom = k;
                break;
            }
        }
        if (fatFrom < levels.length) {
            boolean[] region = isInk.clone();
            List<Item> fat = new ArrayList<>();
            boolean[] cov = coverFrom(region, cw, ch, sc, levels, fatFrom, inkColor, fat, maxItems);
            out.addAll(fat);
            covered = cov;
        }

        // 5) ince çizgiler: iskelet izleme
        boolean[] thin = new boolean[n];
        for (int i = 0; i < n; i++) thin[i] = isInk[i] && !covered[i];
        boolean[] sk = thinning(thin, cw, ch);
        float[] dtThin = dist(thin, cw, ch);
        List<int[]> paths = trace(sk, cw, ch);
        for (int[] pf : paths) {
            if (out.size() >= maxItems) break;
            int len = (pf.length - 2) / 2;
            int[] p = Arrays.copyOfRange(pf, 2, pf.length);
            boolean dead = pf[0] == 0 || pf[1] == 0;
            float[] dts = new float[len];
            for (int i = 0; i < len; i++) dts[i] = dtThin[p[2 * i + 1] * cw + p[2 * i]];
            float[] sd = dts.clone();
            Arrays.sort(sd);
            float w = 2 * sd[Math.max(0, (int) (len * 0.4f))] * sc;
            // sadece kısa ve bir ucu boşta kalan çıkıntıları (iskelet kılları) at
            if (dead && pf[0] + pf[1] >= 1 && len * sc < 0.9f * w) continue;
            if (len < 2) continue;
            float[] pts = rdp(p, 1.0f);
            Item it = new Item();
            it.color = inkColor;
            it.level = nearestLevel(levels, w);
            it.pts = new float[pts.length];
            for (int i = 0; i < pts.length; i += 2) {
                it.pts[i] = (pts[i] + 0.5f) * sc;
                it.pts[i + 1] = (pts[i + 1] + 0.5f) * sc;
            }
            out.add(it);
        }
        // iskeleti olmayan küçük lekeler (nokta/göz): kapsama ile doldur
        boolean[] skD = new boolean[n];
        for (int i = 0; i < n; i++) skD[i] = sk[i];
        boolean[] blobs = new boolean[n];
        boolean any = false;
        int[] lab = new int[n];
        int nl = label(thin, cw, ch, lab);
        int[] skCnt = new int[nl + 1], arCnt = new int[nl + 1];
        for (int i = 0; i < n; i++) {
            if (lab[i] > 0) {
                arCnt[lab[i]]++;
                if (sk[i]) skCnt[lab[i]]++;
            }
        }
        for (int i = 0; i < n; i++) {
            if (lab[i] > 0 && skCnt[lab[i]] <= 2 && arCnt[lab[i]] >= 3) {
                blobs[i] = true;
                any = true;
            }
        }
        if (any && out.size() < maxItems) {
            List<Item> bl = new ArrayList<>();
            coverFrom(blobs, cw, ch, sc, levels, 0, inkColor, bl, maxItems);
            out.addAll(bl);
        }
        return out;
    }


    /** Resmi paletteki en yakın renk indekslerine çevirir (nötr pikseller sadece nötr renklere gider). */
    public static int[] quantize(int[] img, int cw, int ch, int[] pal) {
        int n = cw * ch, np = pal.length;
        float[][] pl = new float[np][];
        boolean[] neutral = new boolean[np];
        for (int i = 0; i < np; i++) {
            double[] l = Planner.lab(pal[i]);
            pl[i] = new float[]{(float) l[0], (float) l[1], (float) l[2]};
            neutral[i] = Math.hypot(l[1], l[2]) < 14;
        }
        int[] idx = new int[n];
        for (int i = 0; i < n; i++) {
            int c = img[i];
            if (((c >>> 24) & 255) < 128) {
                idx[i] = -1;
                continue;
            }
            double[] l = Planner.lab(c);
            boolean neut = Math.hypot(l[1], l[2]) < 12;
            int best = -1;
            double bd = 1e18;
            for (int p = 0; p < np; p++) {
                if (neut && !neutral[p]) continue;
                double dl = l[0] - pl[p][0], da = l[1] - pl[p][1], db = l[2] - pl[p][2];
                double d = dl * dl + da * da + db * db;
                if (d < bd) {
                    bd = d;
                    best = p;
                }
            }
            idx[i] = best;
        }
        return mode3(idx, cw, ch, np);
    }

    // ---------------- yardımcılar ----------------
    static void cover(boolean[] region, int cw, int ch, float sc, float[] levels, int from, int color,
                      List<Item> out, int max) {
        coverFrom(region, cw, ch, sc, levels, from, color, out, max);
    }

    /** Alanı, kalından inceye fırça seviyeleriyle örter; dönen dizi örtülen hücreleri işaretler. */
    static boolean[] coverFrom(boolean[] region, int cw, int ch, float sc, float[] levels, int from, int color,
                               List<Item> out, int max) {
        int n = cw * ch;
        float[] dt = dist(region, cw, ch);
        boolean[] covered = new boolean[n];
        for (int k = levels.length - 1; k >= from; k--) {
            if (out.size() >= max) break;
            float r = Math.max(1f, levels[k] / (2 * sc));
            int step = Math.max(1, Math.round(0.5f * levels[k] / sc));
            int ri = (int) Math.ceil(r);
            for (int y = 0; y < ch; y += step) {
                int x = 0;
                while (x < cw) {
                    if (dt[y * cw + x] >= r - 0.01f && !covered[y * cw + x]) {
                        int xa = x;
                        while (x + 1 < cw && dt[y * cw + x + 1] >= r - 0.01f) x++;
                        // en az bir örtülmemiş hücre var mı (komşu satırlar dahil)?
                        boolean fresh = false;
                        for (int xx = xa; xx <= x && !fresh; xx++) {
                            for (int dy = -ri / 2; dy <= ri / 2 && !fresh; dy++) {
                                int yy = y + dy;
                                if (yy >= 0 && yy < ch && region[yy * cw + xx] && !covered[yy * cw + xx]) fresh = true;
                            }
                        }
                        if (fresh) {
                            Item it = new Item();
                            it.color = color;
                            it.level = k;
                            it.pts = new float[]{(xa + 0.5f) * sc, (y + 0.5f) * sc, (x + 0.5f) * sc, (y + 0.5f) * sc};
                            out.add(it);
                            stampLine(covered, cw, ch, xa, x, y, r);
                            if (out.size() >= max) return covered;
                        }
                    }
                    x++;
                }
            }
        }
        return covered;
    }

    static void stampLine(boolean[] cov, int cw, int ch, int xa, int xb, int y, float r) {
        int ri = (int) Math.ceil(r);
        float r2 = r * r + 0.5f;
        for (int x = xa; x <= xb; x++) {
            for (int dy = -ri; dy <= ri; dy++) {
                int yy = y + dy;
                if (yy < 0 || yy >= ch) continue;
                for (int dx = -ri; dx <= ri; dx++) {
                    int xx = x + dx;
                    if (xx < 0 || xx >= cw) continue;
                    if (dx * dx + dy * dy <= r2) cov[yy * cw + xx] = true;
                }
            }
        }
    }

    static int nearestLevel(float[] levels, float w) {
        int best = 0;
        float bd = Float.MAX_VALUE;
        for (int i = 0; i < levels.length; i++) {
            float d = Math.abs(levels[i] - w);
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
        return best;
    }

    static int[] mode3(int[] idx, int cw, int ch, int np) {
        int[] out = idx.clone();
        int[] cnt = new int[np];
        for (int y = 1; y < ch - 1; y++) {
            for (int x = 1; x < cw - 1; x++) {
                if (idx[y * cw + x] < 0) continue;
                Arrays.fill(cnt, 0);
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        int v = idx[(y + dy) * cw + x + dx];
                        if (v >= 0) cnt[v]++;
                    }
                }
                int best = idx[y * cw + x];
                for (int p = 0; p < np; p++) if (cnt[p] > cnt[best] + 1) best = p;
                out[y * cw + x] = best;
            }
        }
        return out;
    }

    /** Yaklaşık öklid uzaklık dönüşümü (3-4 chamfer), hücre cinsinden. */
    static float[] dist(boolean[] m, int cw, int ch) {
        int n = cw * ch;
        float[] d = new float[n];
        float INF = 1e9f;
        for (int i = 0; i < n; i++) d[i] = m[i] ? INF : 0;
        for (int y = 0; y < ch; y++) {
            for (int x = 0; x < cw; x++) {
                int i = y * cw + x;
                if (!m[i]) continue;
                float v = INF;
                if (x == 0 || y == 0) v = 1; // kenar = dışarı say
                if (x > 0) v = Math.min(v, d[i - 1] + 1);
                if (y > 0) v = Math.min(v, d[i - cw] + 1);
                if (x > 0 && y > 0) v = Math.min(v, d[i - cw - 1] + 1.4142f);
                if (x < cw - 1 && y > 0) v = Math.min(v, d[i - cw + 1] + 1.4142f);
                d[i] = v;
            }
        }
        for (int y = ch - 1; y >= 0; y--) {
            for (int x = cw - 1; x >= 0; x--) {
                int i = y * cw + x;
                if (!m[i]) continue;
                float v = d[i];
                if (x == cw - 1 || y == ch - 1) v = Math.min(v, 1);
                if (x < cw - 1) v = Math.min(v, d[i + 1] + 1);
                if (y < ch - 1) v = Math.min(v, d[i + cw] + 1);
                if (x < cw - 1 && y < ch - 1) v = Math.min(v, d[i + cw + 1] + 1.4142f);
                if (x > 0 && y < ch - 1) v = Math.min(v, d[i + cw - 1] + 1.4142f);
                d[i] = v;
            }
        }
        return d;
    }

    static float medianSkeletonWidth(boolean[] ink, float[] dt, int cw, int ch) {
        boolean[] sk = thinning(ink, cw, ch);
        List<Float> v = new ArrayList<>();
        for (int i = 0; i < sk.length; i++) if (sk[i]) v.add(2 * dt[i]);
        if (v.isEmpty()) return 3;
        Collections.sort(v);
        return v.get(v.size() / 2);
    }

    static int label(boolean[] m, int cw, int ch, int[] lab) {
        int nl = 0;
        int[] stack = new int[m.length];
        for (int i = 0; i < m.length; i++) {
            if (!m[i] || lab[i] != 0) continue;
            nl++;
            int sp = 0;
            stack[sp++] = i;
            lab[i] = nl;
            while (sp > 0) {
                int p = stack[--sp];
                int x = p % cw, y = p / cw;
                for (int k = 0; k < 8; k++) {
                    int nx = x + N8X[k], ny = y + N8Y[k];
                    if (nx < 0 || ny < 0 || nx >= cw || ny >= ch) continue;
                    int q = ny * cw + nx;
                    if (m[q] && lab[q] == 0) {
                        lab[q] = nl;
                        stack[sp++] = q;
                    }
                }
            }
        }
        return nl;
    }

    /** Zhang-Suen inceltme. */
    static boolean[] thinning(boolean[] src, int cw, int ch) {
        boolean[] m = src.clone();
        boolean changed = true;
        List<Integer> del = new ArrayList<>();
        int guard = 0;
        while (changed && guard++ < 200) {
            changed = false;
            for (int step = 0; step < 2; step++) {
                del.clear();
                for (int y = 1; y < ch - 1; y++) {
                    for (int x = 1; x < cw - 1; x++) {
                        int i = y * cw + x;
                        if (!m[i]) continue;
                        boolean p2 = m[i - cw], p3 = m[i - cw + 1], p4 = m[i + 1], p5 = m[i + cw + 1],
                            p6 = m[i + cw], p7 = m[i + cw - 1], p8 = m[i - 1], p9 = m[i - cw - 1];
                        int b = (p2 ? 1 : 0) + (p3 ? 1 : 0) + (p4 ? 1 : 0) + (p5 ? 1 : 0) + (p6 ? 1 : 0)
                            + (p7 ? 1 : 0) + (p8 ? 1 : 0) + (p9 ? 1 : 0);
                        if (b < 2 || b > 6) continue;
                        int a = 0;
                        boolean[] s = {p2, p3, p4, p5, p6, p7, p8, p9, p2};
                        for (int k = 0; k < 8; k++) if (!s[k] && s[k + 1]) a++;
                        if (a != 1) continue;
                        if (step == 0) {
                            if ((p2 && p4 && p6) || (p4 && p6 && p8)) continue;
                        } else {
                            if ((p2 && p4 && p8) || (p2 && p6 && p8)) continue;
                        }
                        del.add(i);
                    }
                }
                for (int i : del) m[i] = false;
                if (!del.isEmpty()) changed = true;
            }
        }
        return m;
    }

    /** İskeleti yollara ayırır; her yol x0,y0,x1,y1,... (hücre koordinatı). */
    static List<int[]> trace(boolean[] sk, int cw, int ch) {
        int n = cw * ch;
        int[] deg = new int[n];
        boolean[] junc = new boolean[n];
        for (int y = 1; y < ch - 1; y++) {
            for (int x = 1; x < cw - 1; x++) {
                int i = y * cw + x;
                if (!sk[i]) continue;
                int c = 0;
                for (int k = 0; k < 8; k++) if (sk[(y + N8Y[k]) * cw + x + N8X[k]]) c++;
                deg[i] = c;
                if (c >= 3) junc[i] = true;
            }
        }
        boolean[] edge = new boolean[n];
        for (int i = 0; i < n; i++) edge[i] = sk[i] && !junc[i];
        int[] lab = new int[n];
        int nl = label(edge, cw, ch, lab);
        List<List<Integer>> comps = new ArrayList<>();
        for (int i = 0; i <= nl; i++) comps.add(new ArrayList<Integer>());
        for (int i = 0; i < n; i++) if (lab[i] > 0) comps.get(lab[i]).add(i);
        List<int[]> paths = new ArrayList<>();
        boolean[] seen = new boolean[n];
        for (int c = 1; c <= nl; c++) {
            List<Integer> pix = comps.get(c);
            int start = pix.get(0);
            for (int p : pix) {
                int cnt = 0;
                for (int k = 0; k < 8; k++) {
                    int q = p + N8Y[k] * cw + N8X[k];
                    if (q >= 0 && q < n && edge[q] && lab[q] == c) cnt++;
                }
                if (cnt <= 1) {
                    start = p;
                    break;
                }
            }
            List<Integer> path = new ArrayList<>();
            int cur = start;
            seen[cur] = true;
            path.add(cur);
            while (true) {
                int nxt = -1, bestD = 9;
                for (int k = 0; k < 8; k++) {
                    int x = cur % cw + N8X[k], y = cur / cw + N8Y[k];
                    if (x < 0 || y < 0 || x >= cw || y >= ch) continue;
                    int q = y * cw + x;
                    if (edge[q] && lab[q] == c && !seen[q]) {
                        int dd = Math.abs(N8X[k]) + Math.abs(N8Y[k]);
                        if (dd < bestD) {
                            bestD = dd;
                            nxt = q;
                        }
                    }
                }
                if (nxt < 0) break;
                seen[nxt] = true;
                path.add(nxt);
                cur = nxt;
            }
            // uçlara komşu kavşak pikseli ekle
            int first = junctionNear(path.get(0), junc, cw, ch);
            int last = junctionNear(path.get(path.size() - 1), junc, cw, ch);
            List<Integer> full = new ArrayList<>();
            if (first >= 0) full.add(first);
            full.addAll(path);
            if (last >= 0 && last != first) full.add(last);
            int[] arr = new int[full.size() * 2 + 2];
            arr[0] = first >= 0 ? 1 : 0;
            arr[1] = (last >= 0 && last != first) ? 1 : 0;
            for (int i = 0; i < full.size(); i++) {
                arr[2 + 2 * i] = full.get(i) % cw;
                arr[2 + 2 * i + 1] = full.get(i) / cw;
            }
            paths.add(arr);
        }
        return paths;
    }

    static int junctionNear(int p, boolean[] junc, int cw, int ch) {
        int x = p % cw, y = p / cw;
        for (int k = 0; k < 8; k++) {
            int nx = x + N8X[k], ny = y + N8Y[k];
            if (nx < 0 || ny < 0 || nx >= cw || ny >= ch) continue;
            if (junc[ny * cw + nx]) return ny * cw + nx;
        }
        return -1;
    }

    /** Ramer-Douglas-Peucker. p: x,y çiftleri. */
    static float[] rdp(int[] p, float eps) {
        int n = p.length / 2;
        if (n <= 2) {
            float[] r = new float[p.length];
            for (int i = 0; i < p.length; i++) r[i] = p[i];
            return r;
        }
        boolean[] keep = new boolean[n];
        keep[0] = keep[n - 1] = true;
        rdpRec(p, 0, n - 1, eps, keep);
        List<Float> o = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (keep[i]) {
                o.add((float) p[2 * i]);
                o.add((float) p[2 * i + 1]);
            }
        }
        float[] r = new float[o.size()];
        for (int i = 0; i < r.length; i++) r[i] = o.get(i);
        return r;
    }

    static void rdpRec(int[] p, int a, int b, float eps, boolean[] keep) {
        if (b <= a + 1) return;
        float ax = p[2 * a], ay = p[2 * a + 1], bx = p[2 * b], by = p[2 * b + 1];
        float dx = bx - ax, dy = by - ay;
        float len = (float) Math.hypot(dx, dy);
        float md = -1;
        int mi = -1;
        for (int i = a + 1; i < b; i++) {
            float d;
            if (len < 1e-6f) d = (float) Math.hypot(p[2 * i] - ax, p[2 * i + 1] - ay);
            else d = Math.abs(dy * (p[2 * i] - ax) - dx * (p[2 * i + 1] - ay)) / len;
            if (d > md) {
                md = d;
                mi = i;
            }
        }
        if (md > eps) {
            keep[mi] = true;
            rdpRec(p, a, mi, eps, keep);
            rdpRec(p, mi, b, eps, keep);
        }
    }
}
