package com.wex1n.draw;

import java.util.ArrayList;
import java.util.List;

/** Tek ince fırçayla, renk indeks haritasını satır satır birebir çizen planlayıcı (saf Java). */
public class Raster {
    /**
     * @param T      hücre başına palet indeksi (-1 = çizme)
     * @param sc     hücre başına ekran pikseli
     * @param brush  fırça çapı (ekran px)
     * @param minRun en az bu kadar hücrelik aralıkları çiz (onarımda küçük gürültüyü atlamak için)
     */
    public static List<LineArt.Item> plan(int[] T, int cw, int ch, float sc, float brush, int np, int minRun,
                                          int maxItems) {
        return plan(T, cw, ch, sc, brush, np, minRun, maxItems, 0.7f, 0f);
    }

    /**
     * @param shrinkFrac vuruş uçlarının, fırça yarıçapının ne kadarı kadar kısaltılacağı (ölçüm hatasına karşı < 1)
     * @param expand     vuruş uçlarını bu kadar piksel uzatır (çizgi kalınlaştırma)
     */
    public static List<LineArt.Item> plan(int[] T, int cw, int ch, float sc, float brush, int np, int minRun,
                                          int maxItems, float shrinkFrac, float expand) {
        List<LineArt.Item> out = new ArrayList<>();
        int[] area = new int[np];
        for (int v : T) if (v >= 0) area[v]++;
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < np; i++) if (area[i] > 0) order.add(i);
        final int[] ar = area;
        java.util.Collections.sort(order, new java.util.Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                return ar[b] - ar[a];
            }
        });
        float rho = brush / 2f;
        float stepY = Math.max(0.45f * brush, 1f);
        int rows = (int) Math.ceil(ch * sc / stepY);
        for (int c : order) {
            for (int r = 0; r < rows; r++) {
                float y = (r + 0.5f) * stepY;
                int j = Math.min(ch - 1, (int) (y / sc));
                int i = 0;
                while (i < cw) {
                    if (T[j * cw + i] != c) {
                        i++;
                        continue;
                    }
                    int i0 = i;
                    while (i + 1 < cw && T[j * cw + i + 1] == c) i++;
                    int i1 = i;
                    i++;
                    if (i1 - i0 + 1 < minRun) continue;
                    float xa = i0 * sc, xb = (i1 + 1) * sc;
                    float x0 = xa + rho * shrinkFrac - expand, x1 = xb - rho * shrinkFrac + expand;
                    if (x1 < x0) {
                        float mid = (xa + xb) / 2f;
                        x0 = mid - expand;
                        x1 = mid + expand;
                    }
                    LineArt.Item it = new LineArt.Item();
                    it.color = c;
                    it.level = 0;
                    it.pts = new float[]{x0, y, x1, y};
                    out.add(it);
                    if (out.size() >= maxItems) return out;
                }
            }
        }
        return out;
    }

    /** Kaynak pikselleri hücre ızgarasına küçültür; ince koyu çizgileri korur (koyu piksel yeterliyse koyu seçer). */
    public static int[] downsample(int[] src, int sw, int sh, int cw, int ch) {
        int[] out = new int[cw * ch];
        for (int j = 0; j < ch; j++) {
            int y0 = j * sh / ch, y1 = Math.max(y0 + 1, (j + 1) * sh / ch);
            for (int i = 0; i < cw; i++) {
                int x0 = i * sw / cw, x1 = Math.max(x0 + 1, (i + 1) * sw / cw);
                long r = 0, g = 0, b = 0, dr = 0, dg = 0, db = 0;
                int n = 0, dark = 0;
                for (int y = y0; y < y1 && y < sh; y++) {
                    for (int x = x0; x < x1 && x < sw; x++) {
                        int c = src[y * sw + x];
                        int cr = (c >> 16) & 255, cg = (c >> 8) & 255, cb = c & 255;
                        r += cr;
                        g += cg;
                        b += cb;
                        n++;
                        if ((cr * 30 + cg * 59 + cb * 11) / 100 < 90) {
                            dark++;
                            dr += cr;
                            dg += cg;
                            db += cb;
                        }
                    }
                }
                if (n == 0) {
                    out[j * cw + i] = 0xFFFFFFFF;
                    continue;
                }
                if (dark * 5 >= n) {
                    out[j * cw + i] = 0xFF000000 | ((int) (dr / dark) << 16) | ((int) (dg / dark) << 8) | (int) (db / dark);
                } else {
                    out[j * cw + i] = 0xFF000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
                }
            }
        }
        return out;
    }
}
