package com.wex1n.draw;

import java.util.ArrayList;
import java.util.List;

/** Tek ince fırçayla, renk indeks haritasını satır satır birebir çizen planlayıcı (saf Java). */
public class Raster {
    /**
     * @param T      hücre başına palet indeksi (-1 = çizme)
     * @param sc     hücre başına ekran pikseli
     * @param brush  fırça çapı (ekran px)
     * @param minRun en az bu kadar hücrelik aralıkları çiz (onarımda küçük gürültüyü atlamak için)
     */
    public static List<LineArt.Item> plan(int[] T, int cw, int ch, float sc, float brush, int np, int minRun,
                                          int maxItems) {
        List<LineArt.Item> out = new ArrayList<>();
        int[] area = new int[np];
        for (int v : T) if (v >= 0) area[v]++;
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < np; i++) if (area[i] > 0) order.add(i);
        final int[] ar = area;
        java.util.Collections.sort(order, new java.util.Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                return ar[b] - ar[a];
            }
        });
        float rho = brush / 2f;
        float stepY = Math.max(0.5f * brush, 1f);
        int rows = (int) Math.ceil(ch * sc / stepY);
        for (int c : order) {
            for (int r = 0; r < rows; r++) {
                float y = (r + 0.5f) * stepY;
                int j = Math.min(ch - 1, (int) (y / sc));
                int i = 0;
                while (i < cw) {
                    if (T[j * cw + i] != c) {
                        i++;
                        continue;
                    }
                    int i0 = i;
                    while (i + 1 < cw && T[j * cw + i + 1] == c) i++;
                    int i1 = i;
                    i++;
                    if (i1 - i0 + 1 < minRun) continue;
                    float xa = i0 * sc, xb = (i1 + 1) * sc;
                    float x0 = xa + rho, x1 = xb - rho;
                    if (x1 < x0) {
                        x0 = x1 = (xa + xb) / 2f;
                    }
                    LineArt.Item it = new LineArt.Item();
                    it.color = c;
                    it.level = 0;
                    it.pts = new float[]{x0, y, x1, y};
                    out.add(it);
                    if (out.size() >= maxItems) return out;
                }
            }
        }
        return out;
    }
}
