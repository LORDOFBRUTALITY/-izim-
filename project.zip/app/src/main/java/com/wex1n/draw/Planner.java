package com.wex1n.draw;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Bir resmi, yalnızca paletteki renklerle, kalından inceye fırça darbelerine çevirir.
 * Saf Java: Android'e bağlı değil, bilgisayarda test edilebilir.
 */
public class Planner {
    public static class Stroke {
        public int color;      // palet indeksi
        public int pass;       // geçiş no (fırça boyutu = sizes[pass])
        public float x0, y0, x1, y1; // resmin sol-üst köşesine göre ekran pikseli
    }

    public static class Plan {
        public List<Stroke> strokes = new ArrayList<>();
        public float[] sizes;
        public int[] passCount;
        public byte[] sim; // simüle edilmiş tuval (palet indeksi), hücre çözünürlüğünde
        public int cw, ch;
    }

    // ---- renk uzayı ----
    static double[] lab(int rgb) {
        double r = lin(((rgb >> 16) & 255) / 255.0), g = lin(((rgb >> 8) & 255) / 255.0), b = lin((rgb & 255) / 255.0);
        double x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047;
        double y = (0.2126 * r + 0.7152 * g + 0.0722 * b);
        double z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883;
        x = f(x);
        y = f(y);
        z = f(z);
        return new double[]{116 * y - 16, 500 * (x - y), 200 * (y - z)};
    }

    static double lin(double c) {
        return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    }

    static double f(double t) {
        return t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16.0 / 116;
    }

    static float dist(float[] a, float[] b) {
        float dl = a[0] - b[0], da = a[1] - b[1], db = a[2] - b[2];
        return (float) Math.sqrt(dl * dl + da * da + db * db);
    }

    /** Özet-alan tablosu (summed-area table) */
    static class Sat {
        final int w, h;
        final float[] v;

        Sat(int w, int h) {
            this.w = w;
            this.h = h;
            this.v = new float[(w + 1) * (h + 1)];
        }

        void build(float[] src) {
            for (int y = 0; y < h; y++) {
                float row = 0;
                for (int x = 0; x < w; x++) {
                    row += src[y * w + x];
                    v[(y + 1) * (w + 1) + x + 1] = v[y * (w + 1) + x + 1] + row;
                }
            }
        }

        float sum(int x0, int y0, int x1, int y1) {
            return v[y1 * (w + 1) + x1] - v[y0 * (w + 1) + x1] - v[y1 * (w + 1) + x0] + v[y0 * (w + 1) + x0];
        }
    }

    static class Run {
        int color, row, i0, i1;
        float y, xa, xb;
    }

    /**
     * @param img  ARGB pikselleri, cw x ch hücre çözünürlüğünde
     * @param sc   bir hücrenin ekran pikseli karşılığı
     * @param pal  palet renkleri (RGB)
     * @param sizes fırça çapları (ekran pikseli), büyükten küçüğe
     * @param ditherFrom bu geçişten itibaren hata yayılımı (titreşim) kullanılır; -1 = hiç
     */
    public static Plan plan(int[] img, int cw, int ch, float sc, int[] pal, float[] sizes, int ditherFrom,
                            int maxStrokes) {
        int n = cw * ch;
        int np = pal.length;
        float[][] pl = new float[np][3];
        for (int i = 0; i < np; i++) {
            double[] l = lab(pal[i]);
            pl[i] = new float[]{(float) l[0], (float) l[1], (float) l[2]};
        }
        float[] tL = new float[n], tA = new float[n], tB = new float[n], tV = new float[n];
        for (int i = 0; i < n; i++) {
            int c = img[i];
            if (((c >>> 24) & 255) < 128) continue;
            double[] l = lab(c);
            tL[i] = (float) l[0];
            tA[i] = (float) l[1];
            tB[i] = (float) l[2];
            tV[i] = 1;
        }
        Sat sL = new Sat(cw, ch), sA = new Sat(cw, ch), sB = new Sat(cw, ch), sV = new Sat(cw, ch);
        sL.build(tL);
        sA.build(tA);
        sB.build(tB);
        sV.build(tV);

        Plan plan = new Plan();
        plan.sizes = sizes;
        plan.cw = cw;
        plan.ch = ch;
        plan.passCount = new int[sizes.length];
        byte[] sim = new byte[n];
        java.util.Arrays.fill(sim, (byte) -1);
        plan.sim = sim;
        Sat qL = new Sat(cw, ch), qA = new Sat(cw, ch), qB = new Sat(cw, ch), qV = new Sat(cw, ch);
        float[] bL = new float[n], bA = new float[n], bB = new float[n], bV = new float[n];

        for (int k = 0; k < sizes.length; k++) {
            if (plan.strokes.size() >= maxStrokes) break;
            float d = sizes[k];
            float dc = Math.max(1f, d / sc);
            float fw = Math.max(1f, dc * 0.8f);
            int nx = cw <= dc ? 1 : (int) Math.ceil((cw - dc) / fw) + 1;
            int ny = ch <= dc ? 1 : (int) Math.ceil((ch - dc) / fw) + 1;
            float[] xc = new float[nx], yc = new float[ny];
            for (int i = 0; i < nx; i++) xc[i] = nx == 1 ? cw / 2f : dc / 2 + i * (cw - dc) / (nx - 1);
            for (int j = 0; j < ny; j++) yc[j] = ny == 1 ? ch / 2f : dc / 2 + j * (ch - dc) / (ny - 1);

            // simülasyon SAT'ları
            for (int i = 0; i < n; i++) {
                int s = sim[i];
                if (s >= 0) {
                    bL[i] = pl[s][0];
                    bA[i] = pl[s][1];
                    bB[i] = pl[s][2];
                    bV[i] = 1;
                } else {
                    bL[i] = bA[i] = bB[i] = bV[i] = 0;
                }
            }
            qL.build(bL);
            qA.build(bA);
            qB.build(bB);
            qV.build(bV);

            float thr = k == 0 ? -1f : 5f;
            boolean dith = ditherFrom >= 0 && k >= ditherFrom;
            List<Run> runs = new ArrayList<>();
            for (int j = 0; j < ny; j++) {
                Run cur = null;
                float eL = 0, eA = 0, eB = 0;
                for (int i = 0; i < nx; i++) {
                    int x0 = Math.max(0, Math.round(xc[i] - fw / 2)), x1 = Math.min(cw, Math.round(xc[i] + fw / 2));
                    int y0 = Math.max(0, Math.round(yc[j] - fw / 2)), y1 = Math.min(ch, Math.round(yc[j] + fw / 2));
                    if (x1 <= x0) x1 = Math.min(cw, x0 + 1);
                    if (y1 <= y0) y1 = Math.min(ch, y0 + 1);
                    float area = (x1 - x0) * (y1 - y0);
                    float nv = sV.sum(x0, y0, x1, y1);
                    if (nv < 0.35f * area) {
                        cur = null;
                        continue;
                    }
                    float[] t = {sL.sum(x0, y0, x1, y1) / nv, sA.sum(x0, y0, x1, y1) / nv, sB.sum(x0, y0, x1, y1) / nv};
                    float[] tp = t;
                    if (dith) tp = new float[]{t[0] + eL, t[1] + eA, t[2] + eB};
                    int pi = nearest(pl, tp);
                    if (dith) {
                        eL = clamp((tp[0] - pl[pi][0]) * 0.5f, 25);
                        eA = clamp((tp[1] - pl[pi][1]) * 0.5f, 25);
                        eB = clamp((tp[2] - pl[pi][2]) * 0.5f, 25);
                    }
                    float painted = qV.sum(x0, y0, x1, y1);
                    boolean need;
                    if (painted < 0.5f * area) {
                        need = true;
                    } else {
                        float[] sm = {qL.sum(x0, y0, x1, y1) / painted, qA.sum(x0, y0, x1, y1) / painted,
                            qB.sum(x0, y0, x1, y1) / painted};
                        need = dist(t, sm) - dist(t, pl[pi]) > thr;
                    }
                    if (!need) {
                        cur = null;
                        continue;
                    }
                    if (cur != null && cur.color == pi && cur.i1 == i - 1) {
                        cur.i1 = i;
                        cur.xb = xc[i];
                    } else {
                        cur = new Run();
                        cur.color = pi;
                        cur.row = j;
                        cur.i0 = cur.i1 = i;
                        cur.y = yc[j];
                        cur.xa = cur.xb = xc[i];
                        runs.add(cur);
                    }
                }
            }
            if (runs.isEmpty()) continue;

            // renk sırası: toplam uzunluğa göre azalan (büyük alanlar önce)
            final float[] tot = new float[np];
            for (Run r : runs) tot[r.color] += (r.xb - r.xa) + 1;
            Collections.sort(runs, new Comparator<Run>() {
                @Override
                public int compare(Run a, Run b) {
                    if (a.color != b.color) return Float.compare(tot[b.color], tot[a.color]);
                    if (a.row != b.row) return a.row - b.row;
                    return a.i0 - b.i0;
                }
            });

            // simülasyonu çizim sırasına göre güncelle
            int r = (int) Math.ceil(dc / 2);
            float r2 = (dc / 2) * (dc / 2);
            int added = 0;
            boolean flip = false;
            int lastColor = -1, lastRow = -1;
            for (Run run : runs) {
                if (plan.strokes.size() >= maxStrokes) break;
                // aynı renkte satırlar arasında yılan gibi git (kalem kaldırma yolunu kısaltır)
                if (run.color != lastColor) {
                    flip = false;
                    lastRow = -1;
                }
                if (run.row != lastRow) {
                    if (lastRow >= 0) flip = !flip;
                    lastRow = run.row;
                }
                lastColor = run.color;
                Stroke s = new Stroke();
                s.color = run.color;
                s.pass = k;
                if (flip) {
                    s.x0 = run.xb * sc;
                    s.x1 = run.xa * sc;
                } else {
                    s.x0 = run.xa * sc;
                    s.x1 = run.xb * sc;
                }
                s.y0 = s.y1 = run.y * sc;
                plan.strokes.add(s);
                added++;
                // damgala
                float len = run.xb - run.xa;
                int steps = Math.max(1, (int) Math.ceil(len));
                for (int st = 0; st <= steps; st++) {
                    float px = run.xa + len * st / steps;
                    int cx = Math.round(px), cy = Math.round(run.y);
                    for (int dy = -r; dy <= r; dy++) {
                        int yy = cy + dy;
                        if (yy < 0 || yy >= ch) continue;
                        for (int dx = -r; dx <= r; dx++) {
                            int xx = cx + dx;
                            if (xx < 0 || xx >= cw) continue;
                            if (dx * dx + dy * dy <= r2 + 0.5f && tV[yy * cw + xx] > 0) sim[yy * cw + xx] = (byte) run.color;
                        }
                    }
                }
            }
            plan.passCount[k] = added;
        }
        return plan;
    }

    static float clamp(float v, float m) {
        return Math.max(-m, Math.min(m, v));
    }

    static int nearest(float[][] pl, float[] t) {
        int best = 0;
        float bd = Float.MAX_VALUE;
        for (int i = 0; i < pl.length; i++) {
            float d = dist(t, pl[i]);
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
        return best;
    }
}
