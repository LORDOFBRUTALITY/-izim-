plugins { id("com.android.application") }
android {
    namespace = "com.wex1n.draw"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.wex1n.draw"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
